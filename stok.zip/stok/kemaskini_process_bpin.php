<html>
<head>
<style>
body{
display: none;}
</style>
</head>
<body>
<!--form method="post" action="senarai_bpin.php"-->
<?php
	include_once 'database.php';
	if(isset($_POST['update']))
	{	
		$id_bpin = $_REQUEST['id'];
		$rujukan = $_POST['rujukan'];
		$unit_pengukuran = $_POST['unit_pengukuran'];
		$jumlah_stok = $_POST['jumlah_stok'];
		$kuantiti_mohon = $_POST['kuantiti_mohon'];
		$kuantiti_lulus = $_POST['kuantiti_lulus'];
		$catatan = $_POST['catatan'];
		$sql = "UPDATE bpin SET rujukan='$rujukan', unit_pengukuran='$unit_pengukuran', jumlah_stok='$jumlah_stok', kuantiti_mohon='$kuantiti_mohon', 
		kuantiti_lulus='$kuantiti_lulus', catatan='$catatan' WHERE id=$id_bpin;";
		
		echo $sql;
		if (mysqli_query($conn, $sql)) {
		echo "<script>alert('KEMASKINI BORANG PINDAHAN STOK TELAH BERJAYA!');
		window.location.href='senarai_bpin.php';
		</script>";
		} else {
			echo "Error: " . $sql . "
		" . mysqli_error($conn);
			}
		mysqli_close($conn);
	}
?>
</form>
</body>
</html>