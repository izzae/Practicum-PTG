<?php include "conn.php";?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Cetak Borang A/B</title>
</head>
<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `stok` WHERE CONCAT(`kod`,`jenama`, `model`, `jenis`, `ts`) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `stok`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "aset");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}
?>
<style>
.styled-table {
    border-collapse: collapse;
	margin: 200px auto;
    font-size: 15px;
    font-family: sans-serif;
    width: 100%;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
}
.styled-table thead tr {
    background-color: #D7DBDD ;
    color: #ffffff;
    text-align: left;
	color: black;
	font-weight: bold;
	font-size: 18px;
	text-transform:uppercase;
}
.styled-table th,
.styled-table td {
    padding: 12px 15px;
}
.styled-table tbody tr {
    border-bottom: 1px solid #dddddd;
}

.styled-table tbody tr:nth-of-type(even) {
    background-color: #f3f3f3;
}

.styled-table tbody tr:last-of-type {
    border-bottom: 2px solid #D7DBDD;
}
.wrapper1{
  position: absolute;
  margin-top: -200px;
  top: 50%;
  left: 50%;
  transform: translate(-50%,-50%);
}
input[type=text] {
  width: 40%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid black;
  max-width:300px
}

.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 12px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 10px auto;
  cursor: pointer;
}
.container{
  position: relative;
  padding: 20px 50px;
}

.input{
  width: 400px;
  border: 3px solid #fff;
  background: #fff;
  padding: 15px 30px;
  border-radius: 50px;
  outline: none;
  font-size: 18px;
  color: #000000;
}

.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 12px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

</style>
<body>
<?php include 'style\menu2.php';?>

<center><h2>Sila pilih kod sebelum ke Borang A dan Borang B</h2></center>
<form action="senarai_kod.php" method="post">
<div class="wrapper1">
<input type="text" name="valueToSearch" placeholder="Carian" />
<input type="submit" name="search" value="Carian" class="button">
<button class="button" onclick="window.print()" align="right">Cetak Senarai Stok</button>	
</div>		
	<table class="styled-table">
    <thead>
        <tr>
			<th>BIL</th>
            <th>JENIS</th>
			<th>MODEL</th>
			<th>NO.KOD</th>
			<th>KEMASKINI</th>
			<th>CETAK</th>
        </tr>
    </thead>
    <tbody>
        <tr>
	<?php 
	$count = 1;
	while($row = mysqli_fetch_array($search_result)):?>
                <tr>
					<?php $id=$row['id'];?>
					<?php $id2=$row['kod'];?>
					<td><?php echo $count++;?></td>
                    <td><?php echo $row['jenis'];?></td>
                    <td><?php echo $row['model'];?></td>
                    <td><?php echo $row['kod'];?></td>
					<td><center><a href = 'kemaskini_btb.php?id=$id'><img src='image/register.png' width='30' height='30'></a></center></a></button></td>
					<td><center><a href = 'cetak_transaksi_stok_A.php?id=<?php echo $row['id']; ?>&id2=<?php echo $row['kod']; ?>' target='_blank'><img src='image/print.png' width='30' height='30'></a></center></td>
					</tr>
								</tr>
                <?php endwhile;?>
            </table>
        </form>
    </tbody>	
</table>
</body>
</html>	