<?php
include_once 'database.php';
$id_kod = $_REQUEST['id'];
?>
<!DOCTYPE html>
<!--form untuk daftar aset keseluruhan-->
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: white;
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  background-color: #f1f1f1;
}

/* Full-width input fields */
input[type=text], input[type=number], input[type=date], textarea, select {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: white;
  text-transform:uppercase;
}

input[type=text]:focus, input[type=number]:focus, input[type=date]:focus, textarea:focus, select:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid black;
  margin-bottom: 25px;
}

h4 {
	text-align: center;
}

/* Set a style for the submit button */
input[type=submit] {
  background-color: #A6ACAF;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

input[type=submit]:hover {
  opacity: 1;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>

<body>
<?php include 'style\menu2.php';
	$a = "SELECT * FROM stok where id = $id_kod";
		$result = mysqli_query($conn,$a) or die(mysqli_error());
	$row = mysqli_fetch_assoc($result);
?>

<form method="post" action="process_bpsi.php?id=<?php echo $id_kod?>">
  <div class="container">
 
    <h3>DAFTAR PERMOHONAN STOK (INDIVIDU KEPADA STOR) (BPSI)</h3>
    <!--p>Please fill in this form to create an account.</p-->
    <hr>
	
	<label for="name"><b>No. Rujukan BPSI</b></label>
    <input type="text" placeholder="Sila masukkan no. rujukan BPSI" name="rujukan">
	
	<h4>Permohonan</h4>
	<label for="no"><b>No. Kod</b></label>
    <input type="text" placeholder="Sila masukkan no. kod" name="no_kod" value="<?php echo $row['kod'];?>" disabled>

    <label for="item"><b>Perihal Stok</b></label>
    <input type="text" placeholder="Sila masukkan perihal stok" name="perihal_stok" value="<?php echo $row['model'];?>" disabled>
	
	<label for="name"><b>Kuantiti dimohon</b></label>
    <input type="number" placeholder="Sila masukkan kuantiti yang dimohon" name="kuantiti_mohon">
	
	<label for="note"><b>Catatan</b></label>
	<textarea name="catatan_mohon" placeholder="Sila tulis catatan" style="height:200px"></textarea>
	
	<hr>
	
	<h4>Pegawai Pelulus</h4>
	<label for="no"><b>Baki Sedia Ada</b></label>
    <input type="number" placeholder="Sila masukkan baki sedia ada" name="baki" onchange="calculateAmount()" id="baki">
	
	<label for="no"><b>Kuantiti Diluluskan</b></label>
    <input type="number" placeholder="Sila masukkan kuantiti yang diluluskan" name="kuantiti_lulus" onchange="calculateAmount()" id="lulus">

    <label for="note"><b>Catatan</b></label>
	<textarea name="catatan_pegawai" placeholder="Sila tulis catatan" style="height:200px" id="jumlah"></textarea>
	
	<hr>
	
	<h4>Perakuan Penerimaan</h4>
	<label for="code"><b>Kuantiti Diterima</b></label>
    <input type="number" placeholder="Sila masukkan kuantiti yang diterima" name="kuantiti_terima" id="terima">
	
	<label for="note"><b>Catatan</b></label>
	<textarea name="catatan_terima" placeholder="Sila tulis catatan" style="height:200px"></textarea>

	<input type="submit" name="save" value="DAFTAR">
  </div>
</form>
<script>
    function calculateAmount() {
		lulus = document.getElementById("lulus").value;
		baki = document.getElementById("baki").value;
        var jumlah_baki = baki - lulus;
        /*display the result*/
        var papar = document.getElementById("jumlah");
        papar.value = jumlah_baki;
		var display = document.getElementById("terima");
        display.value = lulus;
    }
</script>
</body>
</html>
