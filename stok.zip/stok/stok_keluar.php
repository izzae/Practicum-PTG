<!DOCTYPE html>
<!--form untuk stok keluar-->
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: black;
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  background-color: #f1f1f1;
}

/* Full-width input fields */
input[type=text], input[type=password], input[type=date], input[type=number] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: white;
}

input[type=text]:focus, input[type=password]:focus, input[type=date]:focus, input[type=number]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid black;
  margin-bottom: 25px;
}

h4 {
	text-align: center;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: black;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>
<body>
<?php include 'style\menu2.php';?>
<form action="/action_page.php">
  <div class="container">
    <h1>DAFTAR ASET KELUAR</h1>
    <p>Sila masukkan butiran untuk aset keluar</p>
    <hr>

    <label for="tarikh"><b>Tarikh</b></label>
    <input type="date" name="tarikh" id="tarikh" required>

    <label for="item"><b>No. PK/BTB/BPSS/BPSI/BPIN</b></label>
    <input type="text" placeholder="Sila masukkan no. PK/BTB/BPSS/BPSI/BPIN" name="item" id="item" required>

    <label for="receive"><b>Terima Daripada</b></label>
    <input type="text" placeholder="Sila masukkan terima daripada" name="receive" id="receive" required>
	
	<hr>
	
	<h4>TERIMAAN</h4>
	<label for="qt1"><b>Kuantiti</b></label>
    <input type="number" placeholder="Sila masukkan kuantiti" name="qt1" id="qt1"  min="1" max="500" required>

    <label for="per"><b>Seunit (RM)</label>
    <input type="text" placeholder="Sila masukkan harga seunit" name="per" id="per" required>

    <label for="total"><b>Jumlah (RM)</b></label>
    <input type="text" placeholder="Sila masukkan jumlah" name="total" id="total" required>
	
	<hr>
	
	<h4>KELUARAN</h4>
	<label for="qt2"><b>Kuantiti</b></label>
    <input type="number" placeholder="Sila masukkan kuantiti" name="qt2" id="qt2"  min="1" max="5" required>

    <label for="unit"><b>Jumlah (RM)</b></label>
    <input type="text" placeholder="Sila masukkan jumlah" name="unit" id="unit" required>
	
	<hr>
	
	<h4>BAKI</h4>
	<label for="qt3"><b>Kuantiti</b></label>
    <input type="number" placeholder="Sila masukkan perihal kuantiti" name="qt3" id="qt3"  min="1" max="5" required>

    <label for="unit"><b>Jumlah (RM)</b></label>
    <input type="text" placeholder="Sila masukkan jumlah" name="unit" id="unit" required>
	
	<hr>
	
	<label for="unit"><b>Nama Pegawai</b></label>
    <input type="text" placeholder="Sila masukkan nama pegawai" name="unit" id="unit" required>
    <hr>
    <!--p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p-->

    <button type="submit" class="registerbtn">DAFTAR</button>
  </div>
  
  <!--div class="container signin">
    <p>Already have an account? <a href="#">Sign in</a>.</p>
  </div-->
</form>

</body>
</html>
