<html>
<head>
<style>
body{
display: none;}
</style>
</head>
<body>
<form method="post" action="senarai_btb.php">
<?php
	include_once 'database.php';
	if(isset($_POST['save']))
	{	 
		$rujukan = $_POST['rujukan'];
		$nama_syarikat = $_POST['nama_syarikat'];
		$alamat = $_POST['alamat'];
		$jenis_penerimaan = $_POST['jenis_penerimaan'];
		$no_rujukan = $_POST['no_rujukan'];
		$tkh_pesanan = $_POST['tkh_pesanan'];
		$no_hantaran = $_POST['no_hantaran'];
		$tkh_hantaran = $_POST['tkh_hantaran'];
		$maklumat_hantran = $_POST['maklumat_hantran'];
		$unit_pengukuran = $_POST['unit_pengukuran'];
		$dipesan = $_POST['dipesan'];
		$nota_hantaran = $_POST['nota_hantaran'];
		$diterima = $_POST['diterima'];
		$seunit = $_POST['seunit'];
		$jumlah = $_POST['jumlah'];
		$catatan = $_POST['catatan'];
		$jenama = $_POST['jenama'];
		$jenis = $_POST['jenis'];
		$model = $_POST['model'];
		$kod = $_POST['kod'];
		//$kuantiti = $_POST['kuantiti'];
		//$petunjuk = $_POST['petunjuk'];
		$sql = "INSERT INTO stok (`rujukan`,`nama_syarikat`, `alamat`, `jenis_penerimaan`, `no_rujukan`, `tkh_pesanan`, `no_hantaran`, `tkh_hantaran`, `maklumat_hantran`, 
		`unit_pengukuran`, `dipesan`, `nota_hantaran`, `diterima`, `seunit`, `jumlah`, `catatan`, `jenama`, `jenis`, `model`, `kod`) 
		VALUES ('$rujukan','$nama_syarikat','$alamat','$jenis_penerimaan','$no_rujukan','$tkh_pesanan','$no_hantaran','$tkh_hantaran',
		'$maklumat_hantran','$unit_pengukuran','$dipesan','$nota_hantaran','$diterima','$seunit','$jumlah','$catatan','$jenama','$jenis','$model','$kod')";
		echo $sql;
		
		if (mysqli_query($conn, $sql)) {
		echo "<script>alert('MAKLUMAT DAFTAR TERIMAAN BARANG-BARANG TELAH DITERIMA!');
		window.location.href='senarai_btb.php';
		</script>";
		} else {
			echo "<script>alert('RALAT:' " . $sql . "
		" . mysqli_error($conn);
		"</script>";
			}
		mysqli_close($conn);
	}
?>
</form>
</body>
</html>
