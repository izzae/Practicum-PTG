<!DOCTYPE html>
<html>
<head>
<style>
* {box-sizing: border-box}
body {font-family: "Lato", sans-serif;}


/*body*/
body {font-family: Arial, Helvetica, sans-serif;}
form {border: 3px solid #f1f1f1;
	width: 50%;
	max-width: 500px;
    margin: auto;
}

input[type=text], input[type=password], select{
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
  box-sizing: border-box;
}

button {
  background-color: black;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 0px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
</head>
<body>

<?php
$servername = "localhost";
$dbname="stok";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

//Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>


<!--center><h2>Log masuk ke Daftar Stok</h2></center>

<form action="" method="post">
  <div class="imgcontainer">
    <!--img src="img_avatar2.png" alt="Avatar" class="avatar">
  </div-->
  
<?php include 'style\menu2.php';?>


  <div class="container">
	<div class="main">
  
		<label for="brand"><b>Jenama</b></label>
		<!--input type="text" placeholder="Masukkan kata nama" name="uname" required-->
		<select name="brand">
		<?php
		$sql = "SELECT * FROM perkakasan ";
		$result = mysqli_query($conn,$sql) or die(mysqli_error());
		while($row=mysqli_fetch_assoc($result)) {
		?>
		<option value="<?php echo $row['jenama'];?>">
		<?php echo $row['jenis_perkakasan'];?>
		</option>
		<?php
		} 
		?>
		<select>

		<label for="t"><b>Jenis</b></label>
		<input type="password" placeholder="Masukkan kata laluan" name="psw" required>
		
		<label for="c"><b>Kod</b></label>
		<input type="password" placeholder="Masukkan kata laluan" name="psw" required>
		
		<label for="y"><b>Tahun</b></label>
		<input type="password" placeholder="Masukkan kata laluan" name="psw" required>
			
		<button type="submit">Log masuk</button>
    <!--label>
      <input type="checkbox" checked="checked" name="remember"> Remember me
    </label-->
	</div>
  </div>

  <!--div class="container" style="background-color:#f1f1f1">
    <button type="button" class="cancelbtn">Cancel</button>
    <span class="psw">Forgot <a href="#">password?</a></span>
  </div>
</form-->

</body>
</html>
'