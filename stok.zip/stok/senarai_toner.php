<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php include 'style\menu2.php';?>

<?php
$servername = "localhost";
$dbname="aset";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

//Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>


	
	<?php  
		$a = "SELECT * FROM stok order by kod ASC";
		$result = mysqli_query($conn,$a) or die(mysqli_error());
		echo "<table width='800' border='1'>
		<tr>
			<th>&nbsp;BIL</th>
			<th>&nbsp;JENAMA</th>
			<th>&nbsp;JENIS</th>
			<th>&nbsp;MODEL</th>
			<th>&nbsp;NO.KOD</th>
			<th>&nbsp;KUANTITI</th>
		</tr>";
		  
		while($row = mysqli_fetch_assoc($result))
			{
			echo "<tr>";
			echo "<td>"."<center>" . $row['id'] . "</center>"."</td>";
			echo "<td>" . $row['jenama'] . "</td>";
			echo "<td>" . $row['jenis'] . "</td>";
			echo "<td>" . $row['model'] . "</td>";
			echo "<td>" . $row['kod'] . "</td>";
			echo "<td>"."<center>" . $row['kuantiti'] . "</center>"."</td>";
			echo "</tr>";
			}
		echo "</table>";
		mysqli_close($conn);
	?>
</body>
</html>