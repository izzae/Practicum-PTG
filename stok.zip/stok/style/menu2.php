<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

.navbar {
  overflow: hidden;
  background-color: #1ABC9C; 
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.subnav {
  float: left;
  overflow: hidden;
}

.subnav .subnavbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .subnav:hover .subnavbtn {
  background-color: #eee;
  color: black;
}

.subnav-content {
  display: none;
  position: absolute;
  left: 0;
  background-color: #1ABC9C;
  width: 100%;
  z-index: 1;
}

.subnav-content a {
  float: left;
  color: white;
  text-decoration: none;
  display: block;
}

.subnav-content a:hover {
  background-color: #eee;
  color: black;
}

.subnav:hover .subnav-content{
  display: block;
}

.show{
	display: block;
}

</style>
</head>
<body>

<div class="navbar">
  <a href="utama.php">Utama</a>
  <div class="subnav">
    <button onclick="myFunction()" class="subnavbtn">Borang <i class="fa fa-caret-down"></i></button>
    <div id="myDropdown" class="subnav-content">
      <a href="daftar_btb.php">Daftar BTB</a>
      <a href="senarai_btb.php">Senarai BTB</a>
	  <a href="senarai_kod_bpss.php">Daftar BPSS</a>
      <a href="senarai_bpss.php">Senarai BPSS</a>
	  <a href="senarai_kod_bpsi.php">Daftar BPSI</a>
      <a href="senarai_bpsi.php">Senarai BPSI</a>
	  <a href="senarai_kod_bpin.php">Daftar BPIN</a>
      <a href="senarai_bpin.php">Senarai BPIN</a>
    </div>
  </div>
  
  <div class="subnav">
    <button onclick="myFunction1()" class="subnavbtn">Stok <i class="fa fa-caret-down"></i></button>
    <div id="myDropdown1" class="subnav-content">
      <a href="senarai_stok.php">Senarai Stok Keseluruhan</a>
    </div>
  </div> 
  
  <div class="subnav">
    <button onclick="myFunction2()" class="subnavbtn">Borang A/B <i class="fa fa-caret-down"></i></button>
    <div id="myDropdown2" class="subnav-content">
		<a href="senarai_kod.php">Cetak Borang A/B</a>
      <!--a href="cetak/cetak_transaksi_stok.php">Cetak Transaksi Semasa</a-->
		<!--a href="cetak/cetak_semula_transaksi_stok.php">Cetak Semula Transaksi Stok</a-->
    </div>
  </div>
   <a href="#contact">Hubungi</a>
  
   <a href="logoutpengguna.php">Log Keluar</a>
</div>

<script>
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

function myFunction1() {
  document.getElementById("myDropdown1").classList.toggle("show");
}

function myFunction2() {
  document.getElementById("myDropdown2").classList.toggle("show");
}
</script>
</body>
</html>
