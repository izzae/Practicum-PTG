<?php
include_once 'database.php';
?><!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: black;
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  background-color: #f1f1f1;
}

/* Full-width input fields */
input[type=text], input[type=password], input[type=date], textarea, select {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: white;
}

input[type=text]:focus, input[type=password]:focus, input[type=date]:focus, textarea:focus, select:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid black;
  margin-bottom: 25px;
}

h4 {
	text-align: center;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: black;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>
  <body>
	<form method="post" action="process.php">
	<div class="container">
	<label for="brand"><b>Jenis</b></label>
		<select name="jenis">
		<?php
		
		$sql = "SELECT * FROM perkakasan";
		$result = mysqli_query($conn,$sql) or die(mysqli_error());
		while($row=mysqli_fetch_assoc($result)) {
		?>
		<option value="<?php $row['petunjuk'];?>">
		<?php echo $row['jenis'];?>
		</option>
		<?php
		} 
		?>
		</select>
<label for="name"><b>Nama Pembekal/Agen Penghantaran/Pemberi</b></label>
    <input type="text" placeholder="Sila masukkan nama pembekal/agen penghantaran/pemberi" name="nama_syarikat">
	
	<label for="address"><b>Alamat Pembekal/Agen Penghantaran/Pemberi</b></label>
    <input type="text" placeholder="Sila masukkan alamat pembekal/agen penghantaran/pemberi" name="alamat">

    <label for="receive"><b>Jenis Penerimaan</b></label>
    <input type="text" placeholder="Sila masukkan perihal jenis penerimaan" name="jenis_penerimaan">
	
	<hr>
	
	<h4>Pesanan Kerajaan (PK)/Kontrak/Surat Kelulusan</h4>
	<label for="no"><b>Nombor/Rujukan</b></label>
    <input type="text" placeholder="Sila masukkan no. kod" name="no_rujukan">

    <label for="item"><b>Tarikh</b></label>
    <input type="date" name="tkh_pesanan">
	
	<hr>
	
	<h4>Nota Hantaran (DO)</h4>
	<label for="code"><b>Nombor</b></label>
    <input type="text" placeholder="Sila masukkan no. kod" name="no_hantaran" >

    <label for="item"><b>Tarikh</b></label>
    <input type="date" name="tkh_hantaran" >
	
	<hr>
	
	<label for="code"><b>Maklumat Penghantaran</b></label>
    <input type="text" placeholder="Sila masukkan no. kod" name="maklumat_hantran" >
	
	<hr>

    <label for="code"><b>No. Kod</b></label>
    <input type="text" placeholder="Sila masukkan no. kod" name="kod" >

    <label for="item"><b>Perihal Barang-Barang</b></label>
    <input type="text" placeholder="Sila masukkan perihal barang-barang" name="model" >

    <label for="unit"><b>Unit Pengukuran</b></label>
    <input type="text" placeholder="Sila masukkan unit pengukuran" name="unit_pengukuran" >
	
	<hr>
	
	<h4>Kuantiti</h4>
	<label for="code"><b>Dipesan (PK)</b></label>
    <input type="text" placeholder="Sila masukkan no. kod" name="dipesan">

    <label for="item"><b>Nota Hantaran (DO)</b></label>
    <input type="text" placeholder="Sila masukkan perihal barang-barang" name="nota_hantaran">

    <label for="unit"><b>Diterima</b></label>
    <input type="text" placeholder="Sila masukkan unit pengukuran" name="diterima">
	
	<hr>
	
	<h4>Harga (RM)</h4>
	<label for="item"><b>Seunit</b></label>
    <input type="text" placeholder="Sila masukkan perihal barang-barang" name="seunit">

    <label for="unit"><b>Jumlah</b></label>
    <input type="text" placeholder="Sila masukkan unit pengukuran" name="jumlah">
	
	<hr>
	
	<label for="note"><b>Catatan</b></label>
	<textarea id="catatan" name="catatan" placeholder="Sila tulis catatan" style="height:200px"></textarea>
		<br><br>
		<input type="submit" name="save" value="submit">
		
		<div class="container">
	</form>
  </body>
</html>