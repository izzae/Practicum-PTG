-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2021 at 09:12 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aset`
--
CREATE DATABASE IF NOT EXISTS `aset` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `aset`;

-- --------------------------------------------------------

--
-- Table structure for table `bpin`
--

CREATE TABLE `bpin` (
  `id` int(11) NOT NULL,
  `rujukan` varchar(50) NOT NULL,
  `no_kod` varchar(50) NOT NULL,
  `perihal_stok` varchar(50) NOT NULL,
  `unit_pengukuran` varchar(50) NOT NULL,
  `jumlah_stok` float NOT NULL,
  `kuantiti_mohon` int(3) NOT NULL,
  `kuantiti_lulus` int(3) NOT NULL,
  `catatan` text NOT NULL,
  `nama_pemohon` varchar(100) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bpin`
--

INSERT INTO `bpin` (`id`, `rujukan`, `no_kod`, `perihal_stok`, `unit_pengukuran`, `jumlah_stok`, `kuantiti_mohon`, `kuantiti_lulus`, `catatan`, `nama_pemohon`, `ts`) VALUES
(1, '', 'KT001', 'TONER HP LJ Q6511A (11A) BLACK', '1', 100, 2, 2, '-TIADA', 'ANIS ASYIKIN BINTI RAHIMI', '2021-06-23 07:59:24'),
(2, '', 'ka002', '', '', 0, 0, 0, '', '', '2021-07-08 11:05:48'),
(5, '', 'KI001', '', '', 1, 1, 1, '', '', '2021-07-13 08:06:47');

-- --------------------------------------------------------

--
-- Table structure for table `bpsi`
--

CREATE TABLE `bpsi` (
  `id` int(3) NOT NULL,
  `rujukan` varchar(50) NOT NULL,
  `no_kod` varchar(15) NOT NULL,
  `perihal_stok` text NOT NULL,
  `kuantiti_mohon` int(2) NOT NULL,
  `catatan_mohon` text NOT NULL,
  `baki` int(3) NOT NULL,
  `kuantiti_lulus` int(3) NOT NULL,
  `catatan_pegawai` text NOT NULL,
  `kuantiti_terima` int(3) NOT NULL,
  `catatan_terima` text NOT NULL,
  `pemohon` varchar(100) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bpsi`
--

INSERT INTO `bpsi` (`id`, `rujukan`, `no_kod`, `perihal_stok`, `kuantiti_mohon`, `catatan_mohon`, `baki`, `kuantiti_lulus`, `catatan_pegawai`, `kuantiti_terima`, `catatan_terima`, `pemohon`, `ts`) VALUES
(5, '2121212121', '', '', 3, '', 12, 3, '', 3, '', '', '2021-07-15 05:13:10'),
(6, '', 'KA003', '', 0, '', 0, 0, '', 0, '', '', '2021-07-15 05:13:33');

-- --------------------------------------------------------

--
-- Table structure for table `bpss`
--

CREATE TABLE `bpss` (
  `id` int(3) NOT NULL,
  `rujukan` varchar(50) NOT NULL,
  `nama_1` varchar(50) NOT NULL,
  `alamat_1` varchar(100) NOT NULL,
  `nama_2` varchar(50) NOT NULL,
  `alamat_2` varchar(100) NOT NULL,
  `no_kod` varchar(50) NOT NULL,
  `perihal_stok` varchar(50) NOT NULL,
  `kuantiti_mohon` int(3) NOT NULL,
  `catatan_pemesan` text NOT NULL,
  `kuantiti_terima` int(3) NOT NULL,
  `unit_pengukuran` varchar(50) NOT NULL,
  `baki_ada` int(3) NOT NULL,
  `kuantiti_lulus` int(3) NOT NULL,
  `seunit` float NOT NULL,
  `jumlah` float NOT NULL,
  `catatan_bekalan` text NOT NULL,
  `kuantiti_keluar` int(3) NOT NULL,
  `pembungkusan` varchar(15) NOT NULL,
  `pemohon` varchar(500) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bpss`
--

INSERT INTO `bpss` (`id`, `rujukan`, `nama_1`, `alamat_1`, `nama_2`, `alamat_2`, `no_kod`, `perihal_stok`, `kuantiti_mohon`, `catatan_pemesan`, `kuantiti_terima`, `unit_pengukuran`, `baki_ada`, `kuantiti_lulus`, `seunit`, `jumlah`, `catatan_bekalan`, `kuantiti_keluar`, `pembungkusan`, `pemohon`, `ts`, `status`) VALUES
(7, '', '', '', '', '', '', 'KT010', 0, '', 0, 'unit', 0, 0, 0, 0, '', 0, '', '', '2021-07-07 03:31:34', ''),
(8, '', '', '', '', '', '', 'KT005', 0, '', 0, 'unit', 0, 0, 0, 0, '', 0, '', '', '2021-07-07 03:32:27', ''),
(9, '', '', '', '', '', '', 'TONER HP LJ Q5949A (49A) BLACK', 0, '', 0, 'unit', 0, 0, 0, 0, '', 0, '', '', '2021-07-07 03:36:36', ''),
(13, '', '', '', '', '', 'KI017', 'INK CARTRIDGE CANON CLI-(8C CYAN)', 0, '', 0, 'unit', 0, 0, 0, 0, '', 0, '', '', '2021-07-11 03:17:29', ''),
(14, '', '', '', '', '', 'KI006', 'INK CARTRIDGE C9391A (88XL) CYAN', 3, '', 3, 'unit', 18, 8, 0, 0, '', 0, '', '', '2021-07-11 07:04:29', ''),
(15, '', '', '', '', '', 'KI005', 'INK CARTRIDGE C9396A (88XL) BLACK', 8, '', 7, 'unit', 0, 7, 18, 126, '0', 7, '', '', '2021-07-12 00:37:46', '');

-- --------------------------------------------------------

--
-- Table structure for table `log_trail`
--

CREATE TABLE `log_trail` (
  `id_lt` int(11) NOT NULL,
  `menu` varchar(20) NOT NULL,
  `ket` varchar(255) NOT NULL,
  `id_pengguna` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` int(11) NOT NULL,
  `nama_pengguna` varchar(255) NOT NULL,
  `nokp_pengguna` varchar(12) NOT NULL,
  `jabatan` varchar(100) NOT NULL,
  `katalaluan` varchar(50) NOT NULL,
  `level` varchar(50) NOT NULL,
  `masa` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `nama_pengguna`, `nokp_pengguna`, `jabatan`, `katalaluan`, `level`, `masa`) VALUES
(1, 'NUR ANIS ASYIKIN BINTI RAHIMI', '000806020212', 'PTG', 'ABC123', 'pengguna', '2021-07-13 03:34:18'),
(2, 'admin', '12345678', '', 'admin', 'admin', '2021-07-13 03:34:50');

-- --------------------------------------------------------

--
-- Table structure for table `perkakasan`
--

CREATE TABLE `perkakasan` (
  `id` int(11) NOT NULL,
  `jenis` varchar(100) NOT NULL,
  `petunjuk` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `perkakasan`
--

INSERT INTO `perkakasan` (`id`, `jenis`, `petunjuk`) VALUES
(1, 'TONER', 1),
(2, 'INK', 2),
(3, 'ALAT KOMPUTER', 3);

-- --------------------------------------------------------

--
-- Table structure for table `stok`
--

CREATE TABLE `stok` (
  `id` int(11) NOT NULL,
  `rujukan` varchar(50) NOT NULL,
  `nama_syarikat` varchar(500) NOT NULL,
  `alamat` varchar(500) NOT NULL,
  `jenis_penerimaan` varchar(50) NOT NULL,
  `no_rujukan` varchar(50) NOT NULL,
  `tkh_pesanan` date DEFAULT NULL,
  `no_hantaran` varchar(50) NOT NULL,
  `tkh_hantaran` date DEFAULT NULL,
  `maklumat_hantran` text NOT NULL,
  `unit_pengukuran` varchar(50) NOT NULL,
  `dipesan` varchar(50) NOT NULL,
  `nota_hantaran` varchar(50) NOT NULL,
  `diterima` varchar(50) NOT NULL,
  `seunit` float NOT NULL,
  `jumlah` float NOT NULL,
  `baki` int(11) NOT NULL,
  `catatan` text NOT NULL,
  `jenama` varchar(100) NOT NULL,
  `jenis` varchar(255) NOT NULL,
  `model` varchar(100) NOT NULL,
  `kod` varchar(10) NOT NULL,
  `kuantiti` int(2) NOT NULL,
  `petunjuk` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stok`
--

INSERT INTO `stok` (`id`, `rujukan`, `nama_syarikat`, `alamat`, `jenis_penerimaan`, `no_rujukan`, `tkh_pesanan`, `no_hantaran`, `tkh_hantaran`, `maklumat_hantran`, `unit_pengukuran`, `dipesan`, `nota_hantaran`, `diterima`, `seunit`, `jumlah`, `baki`, `catatan`, `jenama`, `jenis`, `model`, `kod`, `kuantiti`, `petunjuk`, `ts`) VALUES
(1, '', 'NURKAMAL SDN BHD', 'NO1,JALAN TEST,05300,ALOR SETAR KEDAH', 'BY HAND', 'PTG/K/A/001', '2021-06-01', 'PTG/K/A1/001', '2021-06-23', 'DITERIMA', 'UNIT', '10', 'DITERIMA', '10', 150, 1500, 0, 'DITERIMA', 'HP', 'TONER ', 'TONER HP LJ Q6511A (11A) BLACK', 'KT001', 0, 1, '2021-07-13 07:12:44'),
(2, '', 'WARISAN TECH SDN. BHD.', 'LOT 82, JALAN SUNGKAI 1, ALOR SETAR KEDAH', 'BY HAND', 'PTG/K/A/002', '2021-06-01', 'DITERIMA', '2021-06-24', 'DITERIMA', 'UNIT', '5', 'DITERIMA', '5', 15, 75, 0, 'DITERIMA', 'HP', 'TONER', 'TONER HP LJ Q2612A (12A) BLACK', 'KT002', 0, 1, '2021-07-13 07:15:30'),
(3, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ Q7516A (16A) BLACK', 'KT003', 0, 1, '2021-05-06 04:42:35'),
(4, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP ', 'TONER', 'TONER HP LJ CB435A (35A) BLACK', 'KT004', 0, 1, '2021-05-06 04:42:49'),
(5, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP ', 'TONER ', 'TONER HP LJ CB436A (36A) BLACK', 'KT005', 0, 1, '2021-05-06 04:42:50'),
(6, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ Q1338A (38A) BLACK', 'KT006', 0, 1, '2021-05-06 04:42:52'),
(7, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ Q5942A (42A) / (42X) BLACK', 'KT007', 0, 1, '2021-05-06 04:42:54'),
(8, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ Q5949A (49A) BLACK', 'KT008', 0, 1, '2021-05-06 04:42:55'),
(9, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ 87551A (51A) BLACK', 'KT009', 0, 1, '2021-05-06 04:42:57'),
(10, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ Q7553A (53A) / (53X) BLACK', 'KT010', 0, 1, '2021-05-06 04:42:59'),
(11, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ Q8061X (61X) BLACK', 'KT011', 0, 1, '2021-05-06 04:43:00'),
(12, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', '', 'FIBER PATCH CORD', '', 'KA020', 0, 0, '2021-05-06 04:42:17'),
(13, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', '', 'UTP CAT6 PATCH CORD', '', 'KA021', 0, 0, '2021-05-06 04:42:17'),
(14, 'u', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', '', '', '', 0, 0, 0, '', '', 'KEYBOARD', '', 'KA001', 0, 0, '2021-07-12 00:57:22'),
(15, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', '', 'MOUSE', '', 'KA002', 0, 0, '2021-07-07 09:01:00'),
(16, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 31, '', '', 'PENDRIVE 32GB', '', 'KA003', 0, 0, '2021-07-15 10:17:52'),
(17, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', '', 'EXTERNAL HARD DISK', '', 'KA004', 0, 0, '2021-05-06 04:42:17'),
(18, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', '', 'HP 4250 MAIN DRIVE ASSEMBLY (LJ4250/4350) RM1-1066-000CN', '', 'KA012', 0, 0, '2021-05-06 04:42:17'),
(19, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', '', 'FIBER TRANCEIVER', '', 'KA019', 0, 0, '2021-05-06 04:42:17'),
(20, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', '', 'HP LASERJET GENUINE HP TRANSFER BELT MAINTENANCE KIT FOR CP5225 (CE516A)', '', 'KA018', 0, 0, '2021-05-06 04:42:17'),
(21, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', '', 'HP OFFICEJET PRO L7380 PRINTER HEAD', '', 'KA017', 0, 0, '2021-05-06 04:42:17'),
(22, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', '', 'HP 4250 FUSER, 220-240V (LJ4200) RM1-0014-140CN', '', 'KA016', 0, 0, '2021-05-06 04:42:17'),
(23, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', '', 'HP 4250 SWING PLATE ASSEMBLY RM1-0043-020CN', '', 'KA015', 0, 0, '2021-05-06 04:42:17'),
(24, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', '', 'HP 4250 LASER/SCANNER ASSEMBLY (LJ4200) RM1-0045-000CN', '', 'KA014', 0, 0, '2021-05-06 04:42:17'),
(25, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', '', 'HP 4250 LASER/SCANNER ASSEMBLY (LJ4250/4350) RM1-1067-000CN', '', 'KA013', 0, 0, '2021-05-06 04:42:17'),
(26, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', '', 'HP 4250 Q5422-67903 LJ4250/4350 220 MAIN KIT', '', 'KA011', 0, 0, '2021-05-06 04:42:17'),
(27, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', '', 'HP 4250 COVER ASSEMBLY, FRONT RM1-0050-030 CN', '', 'KA010', 0, 0, '2021-05-06 04:42:17'),
(28, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', '', 'NETWORK SWITCH', '', 'KA009', 0, 0, '2021-05-06 04:42:17'),
(29, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', '', 'INTERNAL HARDISK', '', 'KA008', 0, 0, '2021-05-06 04:42:17'),
(30, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', '', 'POINTER PRESENTER', '', 'KA007', 0, 0, '2021-05-06 04:42:17'),
(31, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', '', 'BLUETOOTH ADAPTER', '', 'KA006', 0, 0, '2021-05-06 04:42:17'),
(32, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', '', 'SPEAKER', '', 'KA005', 0, 0, '2021-05-06 04:42:17'),
(68, '', 'MECACOM CORPORATION SDN BHD', '', 'beli', '', '0000-00-00', '', '0000-00-00', '', 'unit', '', '', '20', 59, 1180, 0, 'barang-barang diterima', 'HP', '', 'TONER HP LJ Q2612A (12A) BLACK', 'KT002', 0, 0, '2021-07-07 07:19:26'),
(69, '', '', '', 'beli', '', '0000-00-00', '', '0000-00-00', '', 'unit', '20', '', '', 0, 0, 0, 'barang-barang diterima', 'HP ', 'TONER ', 'TONER HP LJ CB436A (36A) BLACK', 'KT005', 0, 0, '2021-07-07 07:22:10'),
(70, '', '', '', 'beli', '', '0000-00-00', '', '0000-00-00', '', 'unit', '', '', '113', 20, 2260, 0, 'barang-barang diterima', 'HP', 'TONER', 'TONER HP LJ Q2612A (12A) BLACK', 'KT002', 0, 0, '2021-07-07 07:23:24'),
(71, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CF280A (80A) BLACK', 'KT012', 0, 0, '2021-07-07 07:32:31'),
(72, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CF281A (81A) BLACK', 'KT013', 0, 0, '2021-07-07 07:32:31'),
(76, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CE285 (85A) BLACK', 'KT014', 0, 0, '2021-07-07 07:34:13'),
(77, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CE390A (90A) BLACK', 'KT015', 0, 0, '2021-07-07 07:36:13'),
(78, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CZ192A (93A) BLACK', 'KT016', 0, 0, '2021-07-07 07:38:45'),
(79, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'EPSON', 'TONER', 'EPSON CARTRIDGE EPL -6200', 'KT017', 0, 0, '2021-07-07 07:38:45'),
(80, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'CANON', 'TONER', 'TONER CANON 312 BLACK', 'KT018', 0, 0, '2021-07-07 07:38:45'),
(81, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'CANON', 'TONER', 'TONER CANON 303 BLACK', 'KT019', 0, 0, '2021-07-07 07:40:17'),
(82, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'FUJI XEROX', 'TONER', 'TONER CARTRIDGE FUJI XEROX INK TONER CT201918 M255', 'KT020', 0, 0, '2021-07-07 07:40:17'),
(83, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'DOCUPRINT', 'TONER', 'DRUM/TONER DOCUPRINT 202/205/255/305', 'KT021', 0, 0, '2021-07-07 07:41:58'),
(84, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'PANASONIC', 'TONER', 'PANASONIC KX-FAD412E DRUM CARTRIDGE', 'KT022', 0, 0, '2021-07-07 07:41:58'),
(85, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'PANASONIC', 'TONER', 'PANASONIC KX-FAT41E TONER', 'KT023', 0, 0, '2021-07-07 07:43:46'),
(86, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'BROTHER', 'TONER', 'DRUM TONER BROTHER DR -2255', 'KT024', 0, 0, '2021-07-07 07:43:46'),
(87, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'BROTHER', 'TONER', 'TONER BROTHER TN-2260', 'KT025', 0, 0, '2021-07-07 07:45:07'),
(88, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CB540A (125A) BLACK', 'KT026', 0, 0, '2021-07-07 07:45:07'),
(89, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CB541A (125A) CYAN', 'KT027', 0, 0, '2021-07-07 07:46:10'),
(90, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ (125A) YELLOW', 'KT028', 0, 0, '2021-07-07 07:46:10'),
(91, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ (125A) MAGENTA', 'KT029', 0, 0, '2021-07-07 07:47:12'),
(92, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CE310A (126A) BLACK', 'KT030', 0, 0, '2021-07-07 07:47:12'),
(93, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CE311A (126A) CYAN', 'KT031', 0, 0, '2021-07-07 07:48:15'),
(94, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CE312A (126A) YELLOW', 'KT032', 0, 0, '2021-07-07 07:48:15'),
(95, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CE313A (126A) MAGENTA', 'KT033', 0, 0, '2021-07-07 07:49:16'),
(96, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CF210A (131A) BLACK', 'KT034', 0, 0, '2021-07-07 07:49:16'),
(97, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CF211A (131A) CYAN', 'KT035', 0, 0, '2021-07-07 07:50:21'),
(98, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CF212A (131A) YELLOW', 'KT036', 0, 0, '2021-07-07 07:50:21'),
(99, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CF213A (131A) MAGENTA', 'KT037', 0, 0, '2021-07-07 07:57:18'),
(100, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CE740A (307A) BLACK', 'KT038', 0, 0, '2021-07-07 07:57:18'),
(101, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CE741A (307A) CYAN', 'KT039', 0, 0, '2021-07-07 07:58:30'),
(102, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CE742A (307A) YELLOW', 'KT040', 0, 0, '2021-07-07 07:58:30'),
(103, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CE743A (307A) MAGENTA', 'KT041', 0, 0, '2021-07-07 07:59:44'),
(104, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'RICOH', 'TONER', 'RICOH SP C220S (BLACK)', 'KT042', 0, 0, '2021-07-07 07:59:44'),
(105, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'RICOH ', 'TONER', 'RICOH SP C220S (CYAN)', 'KT043', 0, 0, '2021-07-07 08:00:47'),
(106, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'RICOH ', 'TONER', 'RICOH SP C220S (YELLOW)', 'KT044', 0, 0, '2021-07-07 08:00:47'),
(107, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'RICOH', 'TONER', 'RICOH SP C220S (MAGENTA)', 'KT045', 0, 0, '2021-07-07 08:01:51'),
(108, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'EPSON', 'TONER', 'EPSON RIBBON CARTRIDGE ERC 27B (BLACK)', 'KT046', 0, 0, '2021-07-07 08:01:51'),
(109, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'EPSON', 'TONER', 'EPSON RIBBON CARTRIDGE LQ-2090', 'KT047', 0, 0, '2021-07-07 08:03:05'),
(110, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CF226XC (26XC) BLACK', 'KT048', 0, 0, '2021-07-07 08:03:05'),
(111, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CF360A (508A) BLACK', 'KT049', 0, 0, '2021-07-07 08:04:22'),
(112, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER ', 'TONER HP LJ CF361A (508A) CYAN', 'KT050', 0, 0, '2021-07-07 08:16:19'),
(113, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CF362A (508A) YELLOW', 'KT051', 0, 0, '2021-07-07 08:05:32'),
(114, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER ', 'TONER HP LJ CF363A (508A) MAGENTA', 'KT052', 0, 0, '2021-07-07 08:05:32'),
(115, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CC530A (304A) BALCK', 'KT053', 0, 0, '2021-07-07 08:08:11'),
(116, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CC531A (304A) CYAN', 'KT054', 0, 0, '2021-07-07 08:08:11'),
(117, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CC532A (304A) YELLOW', 'KT055', 0, 0, '2021-07-07 08:09:23'),
(118, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CC533A (304A) MAGENTA', 'KT056', 0, 0, '2021-07-07 08:09:23'),
(119, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'EPSON', 'TONER', 'EPSON DRUM (PHOTOCONDUCTOR) EPL-6200', 'KT057', 0, 0, '2021-07-07 08:10:37'),
(120, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'RICOH', 'TONER', 'RICOH TONER SP4500LS', 'KT058', 0, 0, '2021-07-07 08:10:37'),
(121, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'RICOH', 'TONER', 'RICOH DRUM SP4500', 'KT059', 0, 0, '2021-07-07 08:11:37'),
(122, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'TONER', 'TONER HP LJ CF237A (37A) BLACK', 'KT060', 0, 0, '2021-07-07 08:11:37'),
(123, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'CANON', 'TONER', 'TONER CANON CART (418BK) BLACK', 'KT061', 0, 0, '2021-07-07 08:12:39'),
(124, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'CANON', 'TONER', 'TONER CANON CART (418C) CYAN', 'KT062', 0, 0, '2021-07-07 08:12:39'),
(125, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'CANON', 'TONER', 'TONER CANON CART (418Y) YELLOW', 'KT063', 0, 0, '2021-07-07 08:13:38'),
(126, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'CANON', 'TONER', 'TONER CANON CART (418M) MAGENTA', 'KT064', 0, 0, '2021-07-07 08:13:38'),
(127, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'EPSON', 'TONER', 'EPSON RIBBON CARTRIDGE LQ310 5015639', 'KT065', 0, 0, '2021-07-07 08:14:55'),
(128, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'BROTHER', 'TONER', 'BROTHER TONER TN 3428', 'KT066', 0, 0, '2021-07-07 08:14:55'),
(129, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'BROTHER', 'TONER', 'BROTHER DRUM DR 3455', 'KT067', 0, 0, '2020-07-07 08:15:37'),
(131, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP ', 'INK', 'INK CARTRIDGE C4937A (18C) CYAN', 'KI002', 0, 0, '2021-07-07 08:23:43'),
(132, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'INK', 'INK CARTRIDGE C4938A (18M) MAGENTA', 'KI003', 0, 0, '2021-07-07 08:24:57'),
(133, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'INK', 'INK CARTRIDGE C4939A (18Y) YELLOW', 'KI004', 0, 0, '2021-07-07 08:24:57'),
(134, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'INK', 'INK CARTRIDGE C9396A (88XL) BLACK', 'KI005', 0, 0, '2021-07-07 08:25:59'),
(135, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'INK', 'INK CARTRIDGE C9391A (88XL) CYAN', 'KI006', 0, 0, '2021-07-07 08:25:59'),
(136, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'INK', 'INK CARTRIDGE C9392A (88XL) MAGENTA', 'KI007', 0, 0, '2021-07-07 08:26:53'),
(137, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'INK', 'INK CARTRIDGE C9393A (88XL) YELLO', 'KI008', 0, 0, '2021-07-07 08:26:53'),
(138, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'INK', 'INK CARTRIDGE CN053AN (932XL) BLACK', 'KI009', 0, 0, '2021-07-07 08:28:39'),
(139, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'INK', 'INK CARTRIDGE CN054AN (933XL) CYAN ', 'KI010', 0, 0, '2021-07-07 08:28:39'),
(140, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'INK', 'INK CARTRIDGE CN055AN (933XL) MAGENTA', 'KI011', 0, 0, '2021-07-07 08:29:42'),
(141, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'INK', 'INK CARTRIDGE CN056AN (933XL) YELLOW', 'KI012', 0, 0, '2021-07-07 08:29:42'),
(142, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'INK', 'INK CARTRIDGE C8767 WA (96) BLACK', 'KI013', 0, 0, '2021-07-07 08:30:54'),
(143, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'INK', 'INK CARTRIDGE C9363 WA (97 TRI COLOR)', 'KI014', 0, 0, '2021-07-07 08:30:54'),
(144, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'CANON', 'INK', 'INK CARTRIDGE CANON 5', 'KI015', 0, 0, '2021-07-07 08:31:47'),
(145, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'CANON', 'INK', 'INK CARTRIDGE CANON CLI-8BK (BLACK)', 'KI016', 0, 0, '2021-07-07 08:31:47'),
(146, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'CANON', 'INK', 'INK CARTRIDGE CANON CLI-(8C CYAN)', 'KI017', 0, 0, '2021-07-07 08:32:55'),
(147, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'CANON', 'INK', 'INK CARTRIDGE CANON CLI-8M (MAGENTA)', 'KI018', 0, 0, '2021-07-07 08:32:55'),
(148, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'CANON', 'INK', 'INK CARTRIDGE CANON CLI-8Y (YELLOW)', 'KI019', 0, 0, '2021-07-07 08:33:54'),
(149, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'CANON', 'INK', 'INK CARTRIDGE CANON PGI 750 PGBK (BLACK)', 'KI020', 0, 0, '2021-07-07 08:33:54'),
(150, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'CANON', 'INK', 'INK CARTRIDGE CANON CLI-751BK (BLACK)', 'KI021', 0, 0, '2021-07-07 08:34:54'),
(151, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'CANON', 'INK', 'INK CARTRIDGE CANON CLI-751C (CYAN)', 'KI022', 0, 0, '2021-07-07 08:34:54'),
(152, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'CANON', 'INK', 'INK CARTRIDGE CANON CLI-751M (MAGENTA)', 'KI023', 0, 0, '2021-07-07 08:35:54'),
(153, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'CANON', 'INK', 'INK CARTRIDGE CANON CLI-751Y (YELLOW)', 'KI024', 0, 0, '2021-07-07 08:35:54'),
(154, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'CANON', 'INK', 'INK CARTRIDGE CANON PGI-820 PGBK BLACK', 'KI025', 0, 0, '2021-07-07 08:36:53'),
(155, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'CANON', 'INK', 'INK CARTRIDGE CANON CLI-821 BK (BLACK)', 'KI026', 0, 0, '2021-07-07 08:36:53'),
(156, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'CANON', 'INK', 'INK CARTRIDGE CANON CLI-821C (CYAN)', 'KI027', 0, 0, '2021-07-07 08:38:28'),
(157, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'CANON', 'INK', 'INK CARTRIDGE CANON CLI-821M (MAGENTA)', 'KI028', 0, 0, '2021-07-07 08:38:28'),
(158, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'CANON', 'INK', 'INK CARTRIDGE CANON CLI-821Y (YELLOW)', 'KI029', 0, 0, '2021-07-07 08:39:27'),
(159, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'INK', 'INK CARTRIDGE HP 955XL (BLACK)', 'KI030', 0, 0, '2021-07-07 08:39:27'),
(160, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'INK', 'INK CARTRIDGE HP 955XL (CYAN)', 'KI031', 0, 0, '2021-07-07 08:40:24'),
(161, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'INK', 'INK CARTRIDGE HP 955XL (YELLOW)', 'KI032', 0, 0, '2021-07-07 08:40:24'),
(162, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 0, '', 'HP', 'INK', 'INK CARTRIDGE HP 955XL (MAGENTA)', 'KI033', 0, 0, '2021-07-07 08:41:58'),
(202, '', '', '', 'beli', '', '0000-00-00', '', '0000-00-00', '', 'unit', '20', '', '20', 23, 460, 0, 'barang-barang diterima', 'CANON', 'INK', 'INK CARTRIDGE', 'KI001', 0, 0, '2021-07-13 06:50:23'),
(207, '', 'MECACOM CORPORATION SDN BHD', 'LOT 89, JALAN PENANG, GEORGETOWN, pULAU pINANG', 'beli', '123456', '2021-07-09', '123456', '2021-07-03', 'barang dihantar', 'unit', '18', '18', '18', 25, 450, 0, 'barang-barang diterima', 'CANON', 'INK', 'INK YELLOW', 'KI001', 0, 0, '2021-07-15 04:26:25'),
(214, '1234567', 'AMAN KOMPUTER', 'sungai petani', 'beli', '123', '2021-07-01', '123', '2021-07-11', 'bekalan mencukupi', 'unit', '22', '22', '22', 20, 440, 0, 'barang-barang diterima', 'HP', 'INK', 'INK CARTRIDGE', 'KI001', 0, 0, '2021-07-15 04:49:07'),
(216, '', '', '', '', '', NULL, '', NULL, '', '', '', '', '', 0, 0, 5, '', '', '', '', '', 0, 0, '2021-07-15 09:31:25');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_stok`
--

CREATE TABLE `transaksi_stok` (
  `id_ts` int(11) NOT NULL,
  `tkh_transaksi` date NOT NULL,
  `no_nota` varchar(100) NOT NULL,
  `terima` varchar(100) NOT NULL,
  `keluar` varchar(100) NOT NULL,
  `kuantiti_terimaan` varchar(100) NOT NULL,
  `seunit_terimaan` varchar(100) NOT NULL,
  `jumlah_terimaan` varchar(100) NOT NULL,
  `kuantiti_keluaran` varchar(100) NOT NULL,
  `jumlah_keluaran` varchar(100) NOT NULL,
  `kuantiti_baki` varchar(100) NOT NULL,
  `jumlah_baki` varchar(100) NOT NULL,
  `nama_pegawai` varchar(100) NOT NULL,
  `status_transaksi` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi_stok`
--

INSERT INTO `transaksi_stok` (`id_ts`, `tkh_transaksi`, `no_nota`, `terima`, `keluar`, `kuantiti_terimaan`, `seunit_terimaan`, `jumlah_terimaan`, `kuantiti_keluaran`, `jumlah_keluaran`, `kuantiti_baki`, `jumlah_baki`, `nama_pegawai`, `status_transaksi`, `ts`) VALUES
(1, '2021-06-01', 'PTG/K/A/001', 'NURKAMAL SDN BHD', '', '10', '150', '1500', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(2, '0000-00-00', 'a', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:27:00'),
(3, '0000-00-00', 'b', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:27:04'),
(4, '0000-00-00', 'c', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:27:07'),
(5, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(6, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(7, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(8, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(9, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(10, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(11, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(12, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(13, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(14, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(15, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(16, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(17, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(18, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(19, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(20, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(21, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(22, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(23, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(24, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(25, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(26, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(27, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(28, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(29, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(30, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(31, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(32, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(33, '0000-00-00', '', 'test', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(34, '0000-00-00', '', 'abc', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(35, '0000-00-00', '123', 'aman', '', '20', '62', '62', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(36, '0000-00-00', '123', 'defg', '', '20', '62', '62', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(37, '0000-00-00', '', 'ljhiuhnkm', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(38, '0000-00-00', '', 'ljhiuhnkm', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(39, '0000-00-00', '', 'dvdgrsgwrr', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(40, '0000-00-00', '', 'wetef', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(41, '0000-00-00', '', 'xxxxxxxx', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(42, '0000-00-00', '', 'zzzzzzz', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(43, '2021-05-09', 'q', 'q', '', 'q', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(44, '2021-05-09', 'q', 'q', '', 'q', '1', '12', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(45, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(46, '0000-00-00', '', 'qqq', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(47, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(48, '0000-00-00', '', '', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(49, '0000-00-00', '', 'ywecnsjinx', '', '', '0', '0', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(50, '0000-00-00', '', '', '', '', '0', '33', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(51, '0000-00-00', '', '', '', '', '0', '33', '', '', '', '', '', 0, '2021-06-23 06:15:21'),
(53, '0000-00-00', '', '', '', '', '', '', '1', '50', '', '', '', 0, '2021-06-23 07:11:55');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bpin`
--
ALTER TABLE `bpin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bpsi`
--
ALTER TABLE `bpsi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bpss`
--
ALTER TABLE `bpss`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `log_trail`
--
ALTER TABLE `log_trail`
  ADD PRIMARY KEY (`id_lt`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`);

--
-- Indexes for table `perkakasan`
--
ALTER TABLE `perkakasan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stok`
--
ALTER TABLE `stok`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaksi_stok`
--
ALTER TABLE `transaksi_stok`
  ADD PRIMARY KEY (`id_ts`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bpin`
--
ALTER TABLE `bpin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `bpsi`
--
ALTER TABLE `bpsi`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `bpss`
--
ALTER TABLE `bpss`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `log_trail`
--
ALTER TABLE `log_trail`
  MODIFY `id_lt` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_pengguna` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `perkakasan`
--
ALTER TABLE `perkakasan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `stok`
--
ALTER TABLE `stok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=217;

--
-- AUTO_INCREMENT for table `transaksi_stok`
--
ALTER TABLE `transaksi_stok`
  MODIFY `id_ts` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
