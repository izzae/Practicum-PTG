<?php
include 'conn.php';
$id_bpss = $_REQUEST['id'];
?>
<!DOCTYPE html>
<!--form untuk daftar aset keseluruhan-->
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: white;
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  background-color: #f1f1f1;
}

/* Full-width input fields */
input[type=text], input[type=password], input[type=date], textarea, select {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: white;
  text-transform:uppercase;
}

input[type=text]:focus, input[type=password]:focus, input[type=date]:focus, textarea:focus, select:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid black;
  margin-bottom: 25px;
}

h4 {
	text-align: center;
}

/* Set a style for the submit button */
input[type=submit] {
  background-color: #A6ACAF;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

input[type=submit]:hover {
  opacity: 1;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>

<body>
<?php
include('style/menu2.php');

	$a = "SELECT * FROM bpss where id = $id_bpss order by no_kod ASC";
		$result = mysqli_query($conn,$a) or die(mysqli_error());
	$row = mysqli_fetch_assoc($result)?>
<form method="post" action="kemaskini_process_bpss.php?id=<?php echo $id_bpss?>">
  <div class="container">
 
    <h3>KEMASKINI PERMOHONAN STOK (ANTARA STOR) (BPSS)</h3>
    <!--p>Please fill in this form to create an account.</p-->
    <hr>
	
	<label for="name"><b>No. Rujukan BPSS</b></label>
    <input type="text" placeholder="Sila masukkan no. rujukan BPSS" name="rujukan" value="<?php echo $row['rujukan'];?>">
	
	<label for="name"><b>Nama Stor Pemesan</b></label>
    <input type="text" name="nama_1" value="<?php echo $row['nama_1'];?>">
	
	<label for="address"><b>Alamat Stor Pemesan</b></label>
    <input type="text" name="alamat_1" value="<?php echo $row['alamat_1'];?>">
	
	<hr>
	
	<h4>Dilengkapkan oleh stor pemesan</h4>
	<label for="no"><b>No. Kod</b></label>
    <input type="text" name="no_kod" value="<?php echo $row['no_kod'];?>">

    <label for="item"><b>Perihal Stok</b></label>
    <input type="text" name="perihal_stok" value="<?php echo $row['perihal_stok'];?>">
	
	<label for="name"><b>Kuantiti dimohon</b></label>
    <input type="text" name="kuantiti_mohon" value="<?php echo $row['kuantiti_mohon'];?>">
	
	<label for="note"><b>Catatan</b></label>
	<textarea name="catatan_pemesan" style="height:200px"><?php echo $row['catatan_pemesan'];?></textarea>

    <label for="receive"><b>Kuantiti Diterima</b></label>
    <input type="text" name="kuantiti_terima" value="<?php echo $row['kuantiti_terima'];?>">
	
	<hr>
	
	<label for="name"><b>Nama Stor Pemesan</b></label>
    <input type="text" name="nama_2" value="<?php echo $row['nama_2'];?>">
	
	<label for="address"><b>Alamat Stor Pemesan</b></label>
    <input type="text" name="alamat_2" value="<?php echo $row['alamat_2'];?>">
	
	<hr>
	
	<h4>Dilengkapkan oleh stor pengeluar</h4>
	<h4>BAHAGIAN BEKALAN KAWALAN DAN AKAUN</h4>
	<label for="no"><b>Unit pengukuran</b></label>
    <input type="text" name="unit_pengukuran" value="<?php echo $row['unit_pengukuran'];?>">
	
	<label for="no"><b>Baki Sedia Ada</b></label>
    <input type="text" name="baki_ada" value="<?php echo $row['baki_ada'];?>">
	
	<label for="no"><b>Kuantiti Diluluskan</b></label>
    <input type="text" name="kuantiti_lulus" value="<?php echo $row['kuantiti_lulus'];?>">
	
	<h4>Harga (RM)</h4>
	
	<label for="no"><b>Seunit</b></label>
    <input type="text" name="seunit" value="<?php echo $row['seunit'];?>">
	
	<label for="no"><b>Jumlah</b></label>
    <input type="text" name="jumlah" value="<?php echo $row['jumlah'];?>">

    <label for="note"><b>Catatan</b></label>
	<textarea name="catatan_bekalan" style="height:200px"><?php echo $row['catatan_bekalan'];?></textarea>
	
	<hr>
	
	<h4>BAHAGIAN SIMPANAN</h4>
	<label for="code"><b>Kuantiti Dikeluarkan</b></label>
    <input type="text" name="kuantiti_keluar" value="<?php echo $row['kuantiti_keluar'];?>">
	
	<label for="code"><b>Pembungkusan (Perlu/Tidak Perlu)</b></label>
    <input type="text" name="pembungkusan" value="<?php echo $row['pembungkusan'];?>">
	
	<label for="code"><b>No. Borang Pembungkusan Stok (BPS)</b></label>
    <input type="text" name="" >

	<input type="submit" name="update" value="KEMASKINI">
  </div>
</form>

</body>
</html>
