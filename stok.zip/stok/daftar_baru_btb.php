<?php
include 'conn.php';
$id_kod = $_REQUEST['id'];
// Storing session data
/*session_start();// Starting session

if(!isset($_SESSION["uname"])){
	header('location:loginpengguna.php');
	exit;
}*/
?>
<!DOCTYPE html>
<!--form untuk daftar aset keseluruhan-->
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: white;
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  background-color: #f1f1f1;
}

/* Full-width input fields */
input[type=text], input[type=number], input[type=date], textarea, select {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: white;
  text-transform:uppercase;
}

input[type=text]:focus, input[type=number]:focus, input[type=date]:focus, textarea:focus, select:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid black;
  margin-bottom: 25px;
}

h4 {
	text-align: center;
}

/* Set a style for the submit button */
input[type=submit] {
  background-color: #A6ACAF;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

input[type=submit]:hover {
  opacity: 1;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>
<body>
<?php include 'style\menu2.php';

	$a = "SELECT * FROM stok where id = $id_kod";
		$result = mysqli_query($conn,$a) or die(mysqli_error());
	$row = mysqli_fetch_assoc($result)
	
?>

<form method="post" action="process_baru_btb.php?id=<?php echo $id_kod?>">
  <div class="container">
 
    <h3>DAFTAR PEMBELIAN STOK SEDIA ADA</h3>
    <!--p>Please fill in this form to create an account.</p-->
    <hr>
	
	<label for="name"><b>No. Rujukan BTB</b></label>
    <input type="text" placeholder="Sila masukkan no. rujukan BTB" name="rujukan" value="<?php echo $row['rujukan'];?>"disabled>
	
	<label for="brand"><b>Jenis</b></label>
	<input type="text" value="<?php echo $row['jenis'];?>" name="jenis">
	
	<hr>
	
	<label for="name"><b>Nama Pembekal/Agen Penghantaran/Pemberi</b></label>
    <input type="text" placeholder="Sila masukkan nama pembekal/agen penghantaran/pemberi" name="nama_syarikat" value="<?php echo $row['nama_syarikat'];?>"disabled>
	
	<label for="address"><b>Alamat Pembekal/Agen Penghantaran/Pemberi</b></label>
    <input type="text" placeholder="Sila masukkan alamat pembekal/agen penghantaran/pemberi" name="alamat" value="<?php echo $row['alamat'];?>"disabled>

    <label for="receive"><b>Jenis Penerimaan</b></label>
    <input type="text" placeholder="Sila masukkan perihal jenis penerimaan" name="jenis_penerimaan" value="beli" value="<?php echo $row['jenis_penerimaan'];?>"disabled>
	
	<hr>
	
	<h4>Pesanan Kerajaan (PK)/Kontrak/Surat Kelulusan</h4>
	<label for="no"><b>Nombor/Rujukan</b></label>
    <input type="text" placeholder="Sila masukkan no. rujukan" name="no_rujukan" value="<?php echo $row['no_rujukan'];?>"disabled>

    <label for="item"><b>Tarikh</b></label>
    <input type="date" name="tkh_pesanan" value="<?php echo $row['tkh_pesanan'];?>"disabled>
	
	<hr>
	
	<h4>Nota Hantaran (DO)</h4>
	<label for="code"><b>Nombor</b></label>
    <input type="text" placeholder="Sila masukkan no. hantaran" name="no_hantaran" value="<?php echo $row['no_hantaran'];?>"disabled>

    <label for="item"><b>Tarikh</b></label>
    <input type="date" name="tkh_hantaran" value="<?php echo $row['tkh_hantaran'];?>"disabled>
	
	<hr>
	
	<label for="code"><b>Maklumat Penghantaran</b></label>
    <input type="text" placeholder="Sila masukkan maklumat penghantaran" name="maklumat_hantran" value="<?php echo $row['maklumat_hantran'];?>"disabled>
	
	<hr>

    <label for="code"><b>No. Kod</b></label>
    <input type="text" placeholder="Sila masukkan no. kod" name="kod" >
	
	<label for="item"><b>Jenama</b></label>
    <input type="text" placeholder="Sila masukkan jenama barang" name="jenama">

    <label for="item"><b>Perihal Barang-Barang</b></label>
    <input type="text" placeholder="Sila masukkan perihal barang-barang" name="model" >

    <label for="unit"><b>Unit Pengukuran</b></label>
    <input type="text" placeholder="Sila masukkan unit pengukuran" name="unit_pengukuran" value="unit" >
	
	<hr>
	
	<h4>Kuantiti</h4>
	<label for="code"><b>Dipesan (PK)</b></label>
    <input type="number" placeholder="Sila masukkan kuantiti yang dipesan" name="dipesan">

    <label for="item"><b>Nota Hantaran (DO)</b></label>
    <input type="text" placeholder="Sila masukkan nota hantaran" name="nota_hantaran">

    <label for="unit"><b>Diterima</b></label>
    <input type="number" placeholder="Sila masukkan kuantiti yang diterima" name="diterima" onchange="calculateAmount()" id="kuantiti">
	
	<hr>
	
	<h4>Harga (RM)</h4>
	<label for="item"><b>Seunit</b></label>
    <input type="number" placeholder="Sila masukkan harga seunit" name="seunit" onchange="calculateAmount()" id="harga">

    <label for="unit"><b>Jumlah</b></label>
    <input type="number" placeholder="Sila masukkan jumlah keseluruhan" name="jumlah" id="jumlah" >
	
	<hr>
	
	<label for="note"><b>Catatan</b></label>
	<textarea name="catatan" placeholder="Sila tulis catatan" style="height:200px">barang-barang diterima</textarea>
    <hr>
	<input type="submit" name="save" value="DAFTAR">
  </div>
</div>
</form>
<script>
    function calculateAmount() {
		kuantiti = document.getElementById("kuantiti").value;
		harga = document.getElementById("harga").value;
        var tot_price = kuantiti * harga;
        /*display the result*/
        var divobj = document.getElementById("jumlah");
        divobj.value = tot_price;
    }
    /*$(document).ready(function(){
		$(".container").on("keyup", ".kuantiti", function(){
		var price = +$(".harga").val;
		var quantity = +$(this).val();
		$("#jumlah").text("$" + price * quantity);
	})
})*/
</script>
</body>
</html>


