<?php
	include_once 'conn.php';
	
	if(isset($_POST['save']))
	{	 
	$id_kod = $_REQUEST['id'];
	echo $id_kod;
		$a = "SELECT * FROM stok where id =$id_kod ";
		$result = mysqli_query($conn,$a) or die(mysqli_error());
		$row = mysqli_fetch_assoc($result);
	
		$rujukan = $_POST['rujukan'];
		$nama_1 = $_POST['nama_1'];
		$alamat_1 = $_POST['alamat_1'];
		$no_kod = $row['kod'];
		$perihal_stok = $row['model'];
		$kuantiti_mohon = $_POST['kuantiti_mohon'];
		$catatan_pemesan = $_POST['catatan_pemesan'];
		$kuantiti_terima = $_POST['kuantiti_terima'];
		$nama_2 = $_POST['nama_2'];
		$alamat_2 = $_POST['alamat_2'];
		$unit_pengukuran = $_POST['unit_pengukuran'];
		$baki_ada = $_POST['baki_ada'];
		$kuantiti_lulus = $_POST['kuantiti_lulus'];
		$seunit = $_POST['seunit'];
		$jumlah = $_POST['jumlah'];
		$baki = $_POST['baki'];
		$kuantiti_keluar = $_POST['kuantiti_keluar'];
		$pembungkusan = $_POST['pembungkusan'];
		$catatan_bekalan = $_POST['catatan_bekalan'];
		
		$sql = "INSERT INTO bpss (`rujukan`, `nama_1`, `alamat_1`, `no_kod`, `perihal_stok`, `kuantiti_mohon`, `catatan_pemesan`, `kuantiti_terima`, `nama_2`, 
		`alamat_2`, `unit_pengukuran`, `baki_ada`, `kuantiti_lulus`, `seunit`, `jumlah`, `kuantiti_keluar`, `pembungkusan`,`catatan_bekalan`) 
		VALUES ('$rujukan','$nama_1','$alamat_1','$no_kod','$perihal_stok','$kuantiti_mohon','$catatan_pemesan','$kuantiti_terima','$nama_2','$alamat_2','$unit_pengukuran',
		'$baki_ada','$kuantiti_lulus','$seunit','$jumlah','$kuantiti_keluar','$pembungkusan','$catatan_bekalan')";
		echo $sql;
		
		//$sql .= "UPDATE stok SET baki='$baki' where id ='$id_kod'";
	
		echo $sql;
		
		if (mysqli_multi_query($conn, $sql)) {
		echo "<script>alert('MAKLUMAT DAFTAR PERMOHONAN STOK (ANTARA STOR) TERIMAAN BARANG-BARANG TELAH DITERIMA!');
		window.location.href='senarai_bpss.php';
		</script>";
		} else {
			echo "Error: " . $sql . "
		" . mysqli_error($conn);
			}
		mysqli_close($conn);
	}
?>
