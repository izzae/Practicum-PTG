<html>
<head>
<style>
body{
display: none;}
</style>
</head>
<body>
<!--form method="post" action="senarai_btb.php"-->
<?php
	include_once 'conn.php';
	if(isset($_POST['update']))
	{	 
		$id_btb = $_REQUEST['id'];
		
		$rujukan = $_POST['rujukan'];
		$nama_syarikat = $_POST['nama_syarikat'];
		$alamat = $_POST['alamat'];
		$jenis_penerimaan = $_POST['jenis_penerimaan'];
		$no_rujukan = $_POST['no_rujukan'];
		$tkh_pesanan = $_POST['tkh_pesanan'];
		$no_hantaran = $_POST['no_hantaran'];
		$tkh_hantaran = $_POST['tkh_hantaran'];
		$maklumat_hantran = $_POST['maklumat_hantran'];
		$unit_pengukuran = $_POST['unit_pengukuran'];
		$dipesan = $_POST['dipesan'];
		$nota_hantaran = $_POST['nota_hantaran'];
		$diterima = $_POST['diterima'];
		$seunit = $_POST['seunit'];
		$jumlah = $_POST['jumlah'];
		$catatan = $_POST['catatan'];
		$jenama = $_POST['jenama'];
		//$jenis = $_POST['jenis'];---xguna dah
		$model = $_POST['model'];
		$kod = $_POST['kod'];
		//$kuantiti = $_POST['kuantiti'];
		$petunjuk = $_POST['petunjuk'];
		$sql = "UPDATE stok SET rujukan='$rujukan',nama_syarikat='$nama_syarikat', alamat='$alamat', jenis_penerimaan='$jenis_penerimaan', no_rujukan='$no_rujukan', tkh_pesanan='$tkh_pesanan', 
		no_hantaran='$no_hantaran', tkh_hantaran='$tkh_hantaran', maklumat_hantran='$maklumat_hantran', unit_pengukuran='$unit_pengukuran', dipesan='$dipesan',
		nota_hantaran='$nota_hantaran', diterima='$diterima', seunit='$seunit', jumlah='$jumlah', catatan='$catatan', jenama='$jenama', model='$model',
		kod='$kod', petunjuk='$petunjuk' WHERE id=$id_btb";
		echo $sql;
		
		if (mysqli_query($conn, $sql)) {
		echo "<script>alert('KEMASKINI TERIMAAN BARANG-BARANG (BTB) TELAH BERJAYA!');
		window.location.href='senarai_btb.php';
		</script>";
		} else {
			echo "<script>alert('RALAT:' " . $sql . "
		" . mysqli_error($conn);
		"</script>";
			}
		mysqli_close($conn);
	}
	//header("senarai_btb.php");
?>
</form>
</body>
</html>