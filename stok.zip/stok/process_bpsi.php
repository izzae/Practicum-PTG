<html>
<head>
<style>
body{
display: none;}
</style>
</head>
<body>
<form method="post" action="senarai_bpsi.php">
<?php
	include_once 'database.php';
	if(isset($_POST['save']))
	{
	$id_kod = $_REQUEST['id'];
	echo $id_kod;
		$a = "SELECT * FROM stok where id =$id_kod ";
		$result = mysqli_query($conn,$a) or die(mysqli_error());
		$row = mysqli_fetch_assoc($result);	
		
		$rujukan = $_POST['rujukan'];
		$no_kod = $row['kod'];
		$perihal_stok = $row['model'];
		$kuantiti_mohon = $_POST['kuantiti_mohon'];
		$catatan_mohon = $_POST['catatan_mohon'];
		$baki = $row['diterima'];
		$kuantiti_lulus = $_POST['kuantiti_lulus'];
		$catatan_pegawai = $_POST['catatan_pegawai'];
		$kuantiti_terima = $_POST['kuantiti_terima'];
		$catatan_terima = $_POST['catatan_terima'];
		$sql = "INSERT INTO bpsi (`rujukan`,`no_kod`, `perihal_stok`, `kuantiti_mohon`, `catatan_mohon`, `baki`, `kuantiti_lulus`, 
		`catatan_pegawai`, `kuantiti_terima`, `catatan_terima`) 
		VALUES ('$rujukan','$no_kod','$perihal_stok','$kuantiti_mohon','$catatan_mohon','$baki',
		'$kuantiti_lulus','$catatan_pegawai','$kuantiti_terima','$catatan_terima')";
		echo $sql;
		
		/*$sqla="SELECT('keluar','kuantiti_keluaran','jumlah_keluaran') 
		VALUES ('$nama_syarikat','$kuantiti_lulus','$jumlah') FROM transaksi_stok";*/
		
		if (mysqli_query($conn, $sql)) {
		echo "<script>alert('MAKLUMAT DAFTAR PERMOHONAN STOK (INDIVIDU KEPADA STOR) TELAH DITERIMA!');
		window.location.href='senarai_bpsi.php';
		</script>";
		} else {
			echo "Error: " . $sql . "
		" . mysqli_error($conn);
			}
		mysqli_close($conn);
	}
?>
</form>
</body>
</html>