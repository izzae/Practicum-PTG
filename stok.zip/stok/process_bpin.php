<html>
<head>
<style>
body{
display: none;}
</style>
</head>
<body>
<form method="post" action="senarai_bpin.php">
<?php
	include_once 'database.php';
	if(isset($_POST['save']))
	{	 
	$id_kod = $_REQUEST['id'];
	echo $id_kod;
		$a = "SELECT * FROM stok where id =$id_kod ";
		$result = mysqli_query($conn,$a) or die(mysqli_error());
		$row = mysqli_fetch_assoc($result);
		
		$rujukan = $_POST['rujukan'];
		$no_kod = $row['kod'];
		$perihal_stok = $row['model'];
		$unit_pengukuran = $_POST['unit_pengukuran'];
		$jumlah_stok = $_POST['jumlah_stok'];
		$kuantiti_mohon = $_POST['kuantiti_mohon'];
		$kuantiti_lulus = $_POST['kuantiti_lulus'];
		$catatan = $_POST['catatan'];
		$sql = "INSERT INTO bpin (`rujukan`,`no_kod`, `perihal_stok`, `unit_pengukuran`, `jumlah_stok`, `kuantiti_mohon`, `kuantiti_lulus`, `catatan`) 
		VALUES ('$rujukan','$no_kod','$perihal_stok','$unit_pengukuran','$jumlah_stok','$kuantiti_mohon','$kuantiti_lulus','$catatan')";
		echo $sql;
		if (mysqli_query($conn, $sql)) {
		echo "<script>alert('MAKLUMAT PINDAHAN STOK TELAH DITERIMA!');
		window.location.href='senarai_bpin.php';
		</script>";
		} else {
			echo "Error: " . $sql . "
		" . mysqli_error($conn);
			}
		mysqli_close($conn);
	}
?>
</form>
</body>
</html>