<?php
include_once 'database.php';
$id_kod = $_REQUEST['id'];
?>
<!DOCTYPE html>
<!--form untuk daftar aset keseluruhan-->
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: white;
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  background-color: #f1f1f1;
}

/* Full-width input fields */
input[type=text], input[type=number], input[type=date], textarea, select {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: white;
  text-transform:uppercase;
}

input[type=text]:focus, input[type=number],:focus, input[type=date]:focus, textarea:focus, select:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid black;
  margin-bottom: 25px;
}

h4 {
	text-align: center;
}

/* Set a style for the submit button */
input[type=submit] {
  background-color: #A6ACAF;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

input[type=submit]:hover {
  opacity: 1;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>

<body>
<?php include 'style\menu2.php';
	$a = "SELECT * FROM stok where id = $id_kod";
		$result = mysqli_query($conn,$a) or die(mysqli_error());
	$row = mysqli_fetch_assoc($result);
?>

<form method="post" action="process_bpin.php?id=<?php echo $id_kod?>"">
  <div class="container">
 
    <h3>DAFTAR PINDAHAN STOK (BPIN)</h3>
    <!--p>Please fill in this form to create an account.</p-->
    <hr>
	
	<label for="name"><b>No. Rujukan BPIN</b></label>
    <input type="text" placeholder="Sila masukkan no. rujukan BPIN" name="rujukan">
	
	<label for="no"><b>No. Kod</b></label>
    <input type="text" placeholder="Sila masukkan no. kod" name="no_kod" value="<?php echo $row['kod'];?>" disabled>
	
	<label for="item"><b>Perihal Stok</b></label>
    <input type="text" placeholder="Sila masukkan perihal stok" name="perihal_stok" value="<?php echo $row['model'];?>" disabled>
	
	<label for="no"><b>Unit pengukuran</b></label>
    <input type="text" placeholder="Sila masukkan unit pengukuran" name="unit_pengukuran" value="unit">
	
	<label for="no"><b>Jumlah Nilai Stok</b></label>
    <input type="number" placeholder="Sila masukkan jumlah nilai stok" name="jumlah_stok">
	
	<label for="name"><b>Kuantiti Dimohon</b></label>
    <input type="number" placeholder="Sila masukkan kuantiti yang dimohon" name="kuantiti_mohon">
	
	<label for="receive"><b>Kuantiti Dilulus</b></label>
    <input type="number" placeholder="Sila masukkan kuantiti yang diluluskan" name="kuantiti_lulus">
	
	<label for="note"><b>Catatan</b></label>
	<textarea name="catatan" placeholder="Sila tulis catatan" style="height:200px"></textarea>

	<input type="submit" name="save" value="DAFTAR">
  </div>
</form>
</body>
</html>
