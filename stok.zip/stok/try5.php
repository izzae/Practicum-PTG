<!DOCTYPE html>
<html>
<style>
th,td {
  padding: 5px;
}
</style>
<body>

<h2>The XMLHttpRequest Object</h2>

<form action=""> 
  <label for="brand"><b>No. Kod</b></label>
	<select id="kod" name="kod" onchange="showCustomer(this.value)">
		<?php
		include_once 'database.php';
		$sql = "SELECT * FROM stok ORDER BY KOD asc";
		$resulta = mysqli_query($conn,$sql) or die(mysqli_error());
		while($rowa=mysqli_fetch_array($resulta)) {
		echo "<option value='".$rowa['kod']."'>".$rowa['kod']."</option>";
		//echo "<option value='" . $rowa['model'] . "'>" . $rowa['model'] . " </option>";
		//echo $rowa['kod'];
		echo $_POST['kod'];
		//echo "<input type='text'>" . $rowa['model'];
		//
		?>
		<?}?>
	</select>
</form>
<br>
<div id="txtHint">Customer info will be listed here...</div>

<script>
function showCustomer(str) {
  if (str == "") {
    document.getElementById("txtHint").innerHTML = "";
    return;
  }
  const xhttp = new XMLHttpRequest();
  xhttp.onload = function() {
    document.getElementById("txtHint").innerHTML = this.responseText;
  }
  xhttp.open("GET", "getcustomer.php?q="+str);
  xhttp.send();
}
</script>
</body>
</html>
