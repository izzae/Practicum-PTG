<?php 
include ('../conn.php');
$id_bpss = $_REQUEST['id'];?>
<!doctype html>
<html>
<head>
<style>
	#list, #list td {
  border: 1px solid black;
  border-collapse: collapse;
  text-align: left;
}
	#list th {
  border: 1px solid black;
  border-collapse: collapse;
  background-color: #D7DBDD;
  text-align: center;
}
</style>
<meta charset="utf-8">
<title>Sistem Daftar Stok</title>
</head>

<body>
	<?php
	$a = "SELECT * FROM bpss where id=$id_bpss order by no_kod ASC";
		$result = mysqli_query($conn,$a) or die(mysqli_error());
	$row = mysqli_fetch_assoc($result)?>
	
<table width=100% border="0">
  <tbody>
    <tr>
      <td scope="col" align="left">Pekeliling Perbendaharaan Malaysia</td>
      <td scope="col" align="right">AM 6.5 Lampiran A</td>
    </tr>
  </tbody>
</table>
	<table width=100% border="0" >
  <tbody>
    <tr>
      <th align="right" scope="col">&nbsp;</th>
      <th align="right" scope="col">KEW.PS-7</th>
    </tr>
  </tbody>
</table>
	<br/>
	<table width=100% border="0" >
  <tbody>
    <tr>
      <td>&nbsp;</td>
      <td align="right"><b>No. BPSS: ..............................</b></td>
    </tr>
  </tbody>
</table>
<table width=100% border="0">
  <tbody>
    <tr>
      <th height="57" scope="col"><p>BORANG PERMOHONAN STOK </p>
      <p>(ANTARA STOR)</p></th>
    </tr>
  </tbody>
</table>
	<table id="list" width=100% border="1">
	  <tbody>
	    <tr>
	      <td height="73" colspan="5" scope="col"><b>Nama dan Alamat Stor Pemesan : <?php echo $row["nama_1"];?><br><?php echo $row["alamat_1"];?></b></td>
	      <td colspan="9" scope="col"><b>Nama dan Alamat Stor Pemesan : <?php echo $row["nama_2"];?><br><?php echo $row["alamat_2"];?></b></td>
        </tr>
	    <tr>
	      <th colspan="5" rowspan="2">Dilengkapkan Oleh Stor Pemesan</th>
	      <th colspan="9">Dilengkapkan Oleh Stor Pengeluar</th>
        </tr>
	    <tr>
	      <th colspan="6">BAHAGIAN BEKALAN KAWALAN DAN AKAUN</th>
	      <th colspan="3">BAHAGIAN SIMPANAN</th>
        </tr>
	    <tr>
	      <th width="5%" rowspan="2">No. Kod</th>
	      <th width="8%" rowspan="2">Perihal Stok</th>
	      <th width="7%" rowspan="2">Kuantiti Dimohon</th>
			<th width="6%" rowspan="2">Catatan</th>
	      <th width="6%" rowspan="2">Kuantiti Diterima</th>
	      <th width="7%" rowspan="2">Unit Pengukuran</th>
	      <th width="6%" rowspan="2">Baki Sedia Ada</th>
	      <th width="7%" rowspan="2">Kuantiti Diluluskan</th>
	      <th colspan="2">Harga (RM)</th>
	      <th width="10%" rowspan="2">Catatan</th>
	      <th width="7%" rowspan="2">Kuantiti Dikeluarkan</th>
	      <th width="9%" rowspan="2"><p>Pembungkusan (Perlu/Tidak Perlu)</p></th>
	      <th width="12%" rowspan="2">No. Borang Pembungkusan Stok (BPS)</th>
        </tr>
	    <tr>
	      <th width="5%">Seunit</th>
	      <th width="5%">Jumlah</th>
        </tr>
	    <tr>
	      <td><center><?php echo $row["no_kod"];?></center></td>
	      <td><center><?php echo $row["perihal_stok"];?></center></td>
	      <td><center><?php echo $row["kuantiti_mohon"];?></center></td>
	      <td><center><?php echo $row["catatan_pemesan"];?></center></td>
	      <td><center><?php echo $row["kuantiti_terima"];?></center></td>
	      <td><center><?php echo $row["unit_pengukuran"];?></center></td>
	      <td><center><?php echo $row["baki_ada"];?></center></td>
	      <td><center><?php echo $row["kuantiti_lulus"];?></center></td>
	      <td><center><?php echo $row["seunit"];?></center></td>
	      <td><center><?php echo $row["jumlah"];?></center></td>
	      <td><center><?php echo $row["catatan_bekalan"];?></center></td>
		  <td><center><?php echo $row["kuantiti_keluar"];?></center></td>
	      <td><center><?php echo $row["pembungkusan"];?></center></td>
	      <td>&nbsp;</td>
        </tr>
	    <tr>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
        </tr>
	    <tr>
	      <td colspan="3"><p>Pemohon</p>
            <p>........................................</p>
            <p><b>Nama Pegawai: <?php echo $row["pemohon"];?></b></p>
            <p><b>Jawatan :</b></p>
            <p><b>Jabatan :</b></p>
          <p><b>Tarikh :</b></p></td>
	      <td colspan="2"><p>Pegawai Penerima</p>
			  <p>........................................</p>
            <p><b>Nama Pegawai:</b></p>
            <p><b>Jawatan :</b></p>
            <p><b>Jabatan :</b></p>
			  <p><b>Tarikh :</b></p></td>
	      <td colspan="6"><p>Pegawai Pelulus</p>
			  <p>........................................</p>
            <p><b>Nama Pegawai: </b></p>
            <p><b>Jawatan :</b></p>
            <p><b>Jabatan :</b></p>
          <p><b>Tarikh :</b></p></td>
	      <td colspan="3"><p>Dikeluarkan dan Direkod Oleh:</p>
			  <p>........................................</p>
            <p><b>Nama Pegawai: </b></p>
            <p><b>Jawatan :</b></p>
            <p><b>Jabatan :</b></p>
          <p><b>Tarikh :</b></p></td>
        </tr>
      </tbody>
</table>
	<p>NOTA: Ruangan Tandatangan Boleh Ditandatangani Pada Lampiran Terakhir Sahaja</p>
</body>
</html>