<?php 
include ('../conn.php');
$id_bpin = $_REQUEST['id'];?>

<!doctype html>
<html>
<head>
<style>
	#list, #list td{
  border: 1px solid black;
  border-collapse: collapse;
  text-align: center;
	}
  #list th {
  border: 1px solid black;
  border-collapse: collapse;
  text-align: center;
  background-color: #D7DBDD;
}
	#list2 td{
  border: 1px solid black;
  border-collapse: collapse;
  text-align: left;
	}
</style>
<meta charset="utf-8">
<title>Sistem Daftar Stok</title>
</head>

<body>
	<?php
	$a = "SELECT * FROM bpin where id=$id_bpin order by no_kod ASC";
		$result = mysqli_query($conn,$a) or die(mysqli_error());
	$row = mysqli_fetch_assoc($result)?>
	
<table width=100% border="0">
  <tbody>
    <tr>
      <td scope="col" align="left">Pekeliling Perbendaharaan Malaysia</td>
      <td scope="col" align="right">AM 6.8 Lampiran A</td>
    </tr>
  </tbody>
</table>
	<br/><br/>
<table width=100% border="0" >
  <tbody>
    <tr>
      <th align="right" scope="col">&nbsp;</th>
      <th align="right" scope="col">KEW.PS-17</th>
    </tr>
	  </tbody>
</table>
	<br/>
	<table width=100% border="0" >
  <tbody>
    <tr>
      <td>&nbsp;</td>
      <td align="right">No. Permohonan: ..............................</td>
    </tr>
  </tbody>
</table<br/>
<table width=100% border="0">
  <tbody>
    <tr>
      <th scope="col">BORANG PINDAHAN STOK</th>
    </tr>
  </tbody>
</table>
		<br/><br/><br/>
<table id="list" width=100%>
  <tbody>
    <tr>
      <th width="9%" height="48" scope="col" ><p>No. Kod</p></th>
      <th width="23%" scope="col">Perihal Stok</th>
      <th width="15%" scope="col"><p>Unit Pengukuran</p></th>
      <th width="13%" scope="col"><p>Jumlah Nilai Stok (RM)</p></th>
      <th width="10%" scope="col"><p>Kuantiti Dimohon</p></th>
      <th width="11%" scope="col"><p>Kuantiti Dilulus</p></th>
      <th width="19%" scope="col">Catatan</th>
    </tr>
    <tr>
      <td><?php echo $row["no_kod"];?> </td>
      <td><?php echo $row["perihal_stok"];?>&nbsp;</td>
      <td><?php echo $row["unit_pengukuran"];?>&nbsp;</td>
      <td><?php echo $row["jumlah_stok"];?>&nbsp;</td>
      <td><?php echo $row["kuantiti_mohon"];?>&nbsp;</td>
      <td><?php echo $row["kuantiti_lulus"];?>&nbsp;</td>
      <td><?php echo $row["catatan"];?>&nbsp;</td>
    </tr>
  </tbody>
</table>
		<br/>
<table id="list2" width=100%>
  <tbody>
    <tr>
      <td scope="col">
	  <br/><br/>
	  <p>...................................................................</p>
      <p>(Tandatangan Pemohon)</p>
      <p><b>Nama : <?php echo $row["nama_pemohon"];?></b></p>
      <p><b>Jawatan :</b></p>
      <p><b>Kem./Jab :</b></p>
      <p><b>Tarikh :</b></p></td>
      <td scope="col">
		<br/><br/>
	    <p>...................................................................</p>
        <p>(Tandatangan Pelulus)</p>
        <p><b>Nama :</b></p>
        <p><b>Jawatan :</b></p>
        <p><b>Kem./Jab :</b></p>
      <p><b>Tarikh :</b></p>
		</td>
    </tr>
    <tr>
      <td><p>Dengan ini saya menyerahkan stok yang dinyatakan di atas.</p>
        <br/><br/>
	    <p>...................................................................</p>
        <p>(Tandatangan Penyerah)</p>
        <p><b>Nama :</b></p>
        <p><b>Jawatan :</b></p>
        <p><b>Kem./Jab :</b></p>
      <p><b>Tarikh :</b></p></td>
      <td><p>Dengan ini saya menerima stok yang dinyatakan di atas.</p>
        <br/><br/>
	    <p>...................................................................</p>
        <p>(Tandatangan Penerima)</p>
        <p><b>Nama :</b></p>
        <p><b>Jawatan :</b></p>
        <p><b>Kem./Jab :</b></p>
      <p><b>Tarikh :</b></p></td>
    </tr>
  </tbody>
</table>
</body>
</html>