<?php 
include ('../conn.php');
$id_btb = $_REQUEST['id'];?>
<!doctype html>
<html>
<head>
<style>
  #list, #list td{
  border: 1px solid black;
  border-collapse: collapse;
  text-align: center;
	}
  #list th {
  border: 1px solid black;
  border-collapse: collapse;
  text-align: center;
  background-color: #D7DBDD;
}
	#list2 td{
  border: 1px solid black;
  border-collapse: collapse;
  text-align: left;
	}
</style>
<meta charset="utf-8">
<title>Sistem Daftar Stok</title>
</head>

<body>
	<?php
	$a = "SELECT * FROM stok where id=$id_btb";
		$result = mysqli_query($conn,$a) or die(mysqli_error());
	$row = mysqli_fetch_assoc($result)
	?>
	
	<table width=100%>
  <tbody>
    <tr>
      <td scope="col" align="left">Pekeliling Perbendaharaan Malaysia</td>
      <td scope="col" align="right">AM 6.2 Lampiran A</td>
    </tr>
  </tbody>
</table><br/>
<table width=100% >
  <tbody>
    <tr>
      <th align="right" scope="col">&nbsp;</th>
      <th align="right" scope="col">KEW.PS-1</th>
		
    </tr>
	  </tbody>
</table>
	<br/>
	<table width=100%>
  <tbody>
    <tr>
      <td></td>
      <td align="right">No. Rujukan BTB: ..............................</td>
    </tr>
  </tbody>
</table>
<br/>
<table width=100% border="0">
  <tbody>
    <tr>
      <th scope="col">BORANG TERIMAAN BARANG-BARANG (BTB)</th>
    </tr>
  </tbody>
</table>
<br/>
<table id="list" width=100%>
  <tbody>
    <tr>
      <th rowspan="2" scope="col">Nama dan Alamat 
		Pembekal/Agen
		Penghantaran/Pemberi</th>
      <th rowspan="2" scope="col">Jenis Penerimaan</th>
      <th height="34" colspan="2" scope="col">Pesanan Kerajaan (PK)/Kontrak/Surat Kelulusan</th>
      <th colspan="2" scope="col">Nota Hantaran (DO)</th>
      <th rowspan="2" scope="col">Maklumat Penghantaran</th>
    </tr>
    <tr>
	  <th>Nombor/Rujukan</th>
      <th>Tarikh</th>
      <th>Nombor</th>
      <th>Tarikh</th>
    </tr>
    <tr>
      <td>&nbsp;<B><?php echo $row["nama_syarikat"];?></B><br/><?php echo $row["alamat"];?></td>
      <td>&nbsp;<?php echo $row["jenis_penerimaan"];?></td>
      <td>&nbsp;<?php echo $row["no_rujukan"];?></td>
      <td>&nbsp;<?php echo $row["tkh_pesanan"];?></td>
      <td>&nbsp;<?php echo $row["no_hantaran"];?></td>
      <td>&nbsp;<?php echo $row["tkh_hantaran"];?></td>
      <td>&nbsp;<?php echo $row["maklumat_hantran"];?></td>
    </tr>
  </tbody>
</table>
<br/>
<table id="list" width=100%>
  <tbody>
    <tr>
      <th width="7%" rowspan="2" scope="col">No. Kod</th>
      <th width="19%" rowspan="2" scope="col">Perihal Barang-Barang </th>
      <th width="16%" rowspan="2" scope="col">Unit Pengukuran</th>
      <th colspan="3" scope="col">Kuantiti</th>
      <th colspan="2" scope="col">Harga (RM)</th>
      <th width="17%" rowspan="2" scope="col">Catatan</th>
    </tr>
    <tr>
      <th width="7%">Dipesan (PK)</th>
      <th width="16%">Nota Hantaran (DO)</th>
      <th width="6%">Diterima</th>
      <th width="6%">Seunit</th>
      <th width="6%">Jumlah</th>
    </tr>
    <tr>
      <td><?php echo $row["kod"];?>&nbsp;</td>
      <td><?php echo $row["jenis"];?><br/><?php echo $row["model"];?></td>
      <td><?php echo $row["unit_pengukuran"];?>&nbsp;</td>
      <td><?php echo $row["dipesan"];?>&nbsp;</td>
      <td><?php echo $row["nota_hantaran"];?>&nbsp;</td>
      <td><?php echo $row["diterima"];?>&nbsp;</td>
      <td><?php echo $row["seunit"];?>&nbsp;</td>
      <td><?php echo $row["jumlah"];?>&nbsp;</td>
      <td><?php echo $row["catatan"];?>&nbsp;</td>
    </tr>
  </tbody>
</table>
<br/>
	<table id=list2 width=100%>
  <tbody>
    <tr>
      <td scope="col">
	  <br/><br/><br/>
	  <p>...................................................................</p>
      <p>(Tandatangan Pegawai Penerima)</p>
      <p><b>Nama :<?php echo @$row["nama_pemohon"];?></b></p>
      <p><b>Jawatan :</b></p>
      <p><b>Jabatan :</b></p>
      <p><b>Tarikh :</b></p></td>
      <td scope="col">
		<br/><br/><br/><br/><br/>
		<p>...................................................................</p>
        <p>(Tandatangan Pegawai Teknikal)</p>
        <p><b>Nama :</b></p>
        <p><b>Jawatan :</b></p>
        <p><b>Jabatan :</b></p>
      <p><b>Tarikh :</b></p>
      <p>*Jika Perlu</p></td>
    </tr>
  </tbody>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
</body>
</html>