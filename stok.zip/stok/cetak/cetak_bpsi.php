<?php 
include ('../conn.php');
$id_bpsi = $_REQUEST['id'];?>
<!doctype html>
<html>
<head>
<style>
	#list, #list td, #list th {
  border: 1px solid black;
  border-collapse: collapse;
  text-align: left;
}
</style>
<meta charset="utf-8">
<title>Sistem Daftar Stok</title>
</head>

<body>
	<?php
	$a = "SELECT * FROM bpsi where id=$id_bpsi order by no_kod ASC";
		$result = mysqli_query($conn,$a) or die(mysqli_error());
	$row = mysqli_fetch_assoc($result)?>
	
<table width=100% border="0">
  <tbody>
    <tr>
      <td scope="col" align="left">Pekeliling Perbendaharaan Malaysia</td>
      <td scope="col" align="right">AM 6.5 Lampiran B</td>
    </tr>
  </tbody>
</table>
	<br/>
<table width=100% border="0" >
  <tbody>
    <tr>
      <th align="right" scope="col">&nbsp;</th>
      <th align="right" scope="col">KEW.PS-8</th>
    </tr>
  </tbody>
</table>
	<br/>
	<table width=100% border="0" >
  <tbody>
    <tr>
      <td>&nbsp;</td>
      <td align="right">No. BPSI: <?php echo $row["rujukan"];?></td>
    </tr>
  </tbody>
</table>
	<br/>
<table width=100% border="0">
  <tbody>
    <tr>
      <th scope="col"><p>BORANG PERMOHONAN STOK </p>
      <p>(INDIVIDU KEPADA STOR) </p></th>
    </tr>
  </tbody>
</table>
	<br/>
	<table id="list" width=100% border="1">
	  <tbody>
	    <tr>
	      <th height="47" colspan="4" scope="col"><center>Permohonan</center></th>
	      <th colspan="3" scope="col"><center>Pegawai Pelulus</center></th>
	      <th colspan="2" scope="col"><center>Perakuan Penerimaan</center></th>
        </tr>
	    <tr>
	      <th width="5%"><center>No. Kod</center></th>
	      <th width="16%"><center>Perihal Stok</center></th>
	      <th width="6%"><center>Kuantiti Dimohon</center></th>
	      <th width="15%"><center>Catatan</center></th>
	      <th width="6%"><center>Baki Sedia Ada</center></th>
	      <th width="8%"><center>Kuantiti Diluluskan</center></th>
	      <th width="17%"><center>Catatan</center></th>
	      <th width="9%"><center>Kuantiti Diterima</center></th>
	      <th width="18%"><center>Catatan</center></th>
        </tr>
		  <tr>
	      <td><center><?php echo $row["no_kod"];?></center></td>
	      <td><center><?php echo $row["perihal_stok"];?></center></td>
	      <td><center><?php echo $row["kuantiti_mohon"];?></center></td>
	      <td><center><?php echo $row["catatan_mohon"];?></center></td>
	      <td><center><?php echo $row["baki"];?></center></td>
	      <td><center><?php echo $row["kuantiti_lulus"];?></center></td>
	      <td><center><?php echo $row["catatan_pegawai"];?></center></td>
	      <td><center><?php echo $row["kuantiti_terima"];?></center></td>
	      <td><center><?php echo $row["catatan_terima"];?></center></td>
        </tr>
	    <tr>
	      <td colspan="4"><br/>
			  <p>Pemohon:</p>
	        <p>...................................................................</p>
	        <p>(Tandatangan)</p>
	        <p><b>Nama: <?php echo $row["pemohon"];?></b></p>
      <p><b>Jawatan :</b></p>
      <p><b>Tarikh :</b></p>
			</td>
	      <td colspan="3"><br/>
			 <p>Pegawai Pelulus:</p>
	        <p>...................................................................</p>
	        <p>(Tandatangan)</p>
	        <p><b>Nama:</b></p>
      <p><b>Jawatan :</b></p>
      <p><b>Tarikh :</b></p>
	      <td colspan="2"><br/>
			<p>Pemohon/Wakil:</p>
	        <p>...................................................................</p>
	        <p>(Tandatangan)</p>
	       <p><b>Nama:</b></p>
      <p><b>Jawatan :</b></p>
      <p><b>Tarikh :</b></p></td>
        </tr>
      </tbody>
</table>
</body>
</html>