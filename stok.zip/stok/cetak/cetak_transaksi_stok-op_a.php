<?php 
include ('../conn.php');
//$id_ts = $_REQUEST['id'];?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
<body>
	<?php
	
	$a = "SELECT * FROM stok ";
		$resulta = mysqli_query($conn,$a);
	
	
	$b = "SELECT * FROM bpin ";
		$resultb = mysqli_query($conn,$b);
	
	?>
<table width=100% border="0">
  <tbody>
    <tr>
      <th scope="col" align="left">Pekeliling Perbendaharaan Malaysia</th>
      <th scope="col" align="right">AM 6.3 Lampiran A</th>
    </tr>
  </tbody>
</table>
<p>&nbsp;</p>
<table width=100% border="0">
  <tbody>
    <tr>
      <th scope="col" align="right">BAHAGIAN B</th>
    </tr>
  </tbody>
</table>
<p>&nbsp;</p>
<table width=100% border="0">
  <tbody>
    <tr>
      <th scope="col" align="left"><p>Transaksi Stok </p></th>
    </tr>
  </tbody>
</table>
<p>&nbsp;</p>
<table width=100% border="1">
	  <tbody>
	    <tr>
	      <th rowspan="2" scope="col">Tarikh</th>
	      <th rowspan="2" scope="col">No. PK/BTB/BPSS/BPSI/BPIN</th>
	      <th rowspan="2" scope="col">Terima Daripada/Keluar Daripada</th>
	      <th colspan="3" scope="col">Terimaan</th>
	      <th colspan="2" scope="col">Keluaran</th>
	      <th colspan="2" scope="col">Baki</th>
	      <th rowspan="2" scope="col">Nama Pegawai</th>
        </tr>
	    <tr>
	      <td>Kuantiti</td>
	      <td>Seunit (RM)</td>
	      <td>Jumlah (RM)</td>
	      <td>Kuantiti</td>
	      <td>Jumlah (RM)</td>
	      <td>Kuantiti</td>
	      <td>Jumlah (RM)</td>
        </tr>
	    <tr>
	      <td></td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td colspan="5">Baki dibawa ke hadapan ....................................................</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
        </tr>
		  
		  <?
		  //if($count==0)
		 // { echo "Tiada Rekod";}
		  //while($rowa=mysqli_fetch_assoc($resulta)){
			   //while($rowb=mysqli_fetch_assoc($resultb))
		  //{
			  if ($resulta->num_rows > 0){
    		// output data of each row
				  while($rowa = $resulta->fetch_assoc()){
			?>
		  
		  <tr>
	      <td><?php echo $rowa["tkh_hantaran"];?>&nbsp;</td>
	      <td><?php echo $rowa["no_rujukan"];?>&nbsp;</td>
	      <td><?php echo $rowa["nama_syarikat"];?>&nbsp;</td>
	      <td><?php echo $rowa["diterima"];?>&nbsp;</td>
	      <td><?php echo $rowa["seunit"];?>&nbsp;</td>
	      <td><?php echo $rowa["jumlah"];?>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
        </tr>
		 
		  <tr>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td><?php echo $rowb["kuantiti_lulus"];?>&nbsp;</td>
	      <td><?php echo $rowb["jumlah_stok"];?>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
			
        </tr> 
      </tbody>
	<?php
			   }
			}
		  ?>	 
</table>
	
	<p>&nbsp;</p>
	<table width="324" border="0">
	  <tbody>
	    <tr>
	      <th width="318" align="left" scope="col">Nota:</th>
        </tr>
	    <tr>
	      <td>PK=Pesanan Kerajaan</td>
        </tr>
	    <tr>
	      <td>BTB=Borang Terimaan Barang-Barang</td>
        </tr>
	    <tr>
	      <td>BPSS=Borang Permohonan Stok (KEW.PS-7)</td>
        </tr>
	    <tr>
	      <td>BPSI=Borang Permohonan Stok (KEW.PS-8)</td>
        </tr>
	    <tr>
	      <td>BPIN=Borang Pindahan Stok (KEW.PS-17)</td>
        </tr>
      </tbody>
</table>
	<p>&nbsp;</p>
</body>
</html>