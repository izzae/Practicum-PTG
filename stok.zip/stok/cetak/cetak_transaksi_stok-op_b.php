<?php 
include ('../conn.php');
//$id_ts = $_REQUEST['id'];?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<?php
	$a = "SELECT * FROM transaksi_stok ";
	//echo $a;
		$result = mysqli_query($conn,$a) or die(mysqli_error());
	$result = $conn->query($a);
	?>
<table width=100% border="0">
  <tbody>
    <tr>
      <th scope="col" align="left">Pekeliling Perbendaharaan Malaysia</th>
      <th scope="col" align="right">AM 6.3 Lampiran A</th>
    </tr>
  </tbody>
</table>
<p>&nbsp;</p>
<table width=100% border="0">
  <tbody>
    <tr>
      <th scope="col" align="right">BAHAGIAN B</th>
    </tr>
  </tbody>
</table>
<p>&nbsp;</p>
<table width=100% border="0">
  <tbody>
    <tr>
      <th scope="col" align="left"><p>Transaksi Stok </p></th>
    </tr>
  </tbody>
</table>
<p>&nbsp;</p>
<table width=100% border="1">
	  <tbody>
	    <tr>
	      <th rowspan="2" scope="col">Tarikh</th>
	      <th rowspan="2" scope="col">No. PK/BTB/BPSS/BPSI/BPIN</th>
	      <th rowspan="2" scope="col">Terima Daripada/Keluar Daripada</th>
	      <th colspan="3" scope="col">Terimaan</th>
	      <th colspan="2" scope="col">Keluaran</th>
	      <th colspan="2" scope="col">Baki</th>
	      <th rowspan="2" scope="col">Nama Pegawai</th>
        </tr>
	    <tr>
	      <td>Kuantiti</td>
	      <td>Seunit (RM)</td>
	      <td>Jumlah (RM)</td>
	      <td>Kuantiti</td>
	      <td>Jumlah (RM)</td>
	      <td>Kuantiti</td>
	      <td>Jumlah (RM)</td>
        </tr>
	    <tr>
	      <td></td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td colspan="5">Baki dibawa ke hadapan ....................................................</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
        </tr>
		  <?
			  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		  
			?>
		  <tr>
	      <td><?php echo $row["tkh_transaksi"];?>&nbsp;</td>
	      <td><?php echo $row["no_nota"];?>&nbsp;</td>
	      <td><?php echo $row["terima"];?>&nbsp;</td>
	      <td><?php echo $row["kuantiti_terimaan"];?>&nbsp;</td>
	      <td><?php echo $row["seunit_terimaan"];?>&nbsp;</td>
	      <td><?php echo $row["jumlah_terimaan"];?>&nbsp;</td>
	      <td><?php echo $row["kuantiti_keluaran"];?>&nbsp;</td>
	      <td><?php echo $row["jumlah_keluaran"];?>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
        </tr>
      </tbody>
	<?
			//$counter++;
			}
		  ?>
</table>
	<?
			  }
			$conn->close();?>
	<p>&nbsp;</p>
	<table width="324" border="0">
	  <tbody>
	    <tr>
	      <th width="318" align="left" scope="col">Nota:</th>
        </tr>
	    <tr>
	      <td>PK=Pesanan Kerajaan</td>
        </tr>
	    <tr>
	      <td>BTB=Borang Terimaan Barang-Barang</td>
        </tr>
	    <tr>
	      <td>BPSS=Borang Permohonan Stok (KEW.PS-7)</td>
        </tr>
	    <tr>
	      <td>BPSI=Borang Permohonan Stok (KEW.PS-8)</td>
        </tr>
	    <tr>
	      <td>BPIN=Borang Pindahan Stok (KEW.PS-17)</td>
        </tr>
      </tbody>
</table>
	<p>&nbsp;</p>
</body>
</html>