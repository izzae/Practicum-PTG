<?php include "conn.php";?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
<style>
table{
 width: 1000px; 
 margin: 30px 0px 30px;
 background-color: #fff;
 font-size: 14px;
 margin-left: auto; 
 margin-right: auto;
 }
 
table tr {
 height: 40px;
 }
 
table th {
 background: #D7DBDD ;
 color: black;
 font-weight: bold;
 font-size: 18px;
 text-transform:uppercase;
}

table td, th{
 padding: 6px 6px 6px 10px;
 border: hidden;
 text-align:left;
}
</style>
<body>
<?php include 'style\menu2.php';?>

<center><h1>Selamat Datang</h1>
<?php
echo "Hari ini " . date("d-m-Y") . "&nbsp;";

echo date("l");
?></center>

		<?php  
		$a = 'select * from stok order by kod asc';
		//$a = "SELECT * FROM stok order by kod ASC";
		$result = mysqli_query($conn,$a) or die(mysqli_error());
		echo "<table width='1000' border='1'>
		<tr>
			<th>&nbsp;Bil</th>
			<th>&nbsp;No. Kod</th>
			<th>&nbsp;Model</th>
			<th>&nbsp;Jenama</th>
			<th>&nbsp;Kuantiti</th>
		</tr>";
		
		$counter = 1;
		while($row = mysqli_fetch_assoc($result))
			{
			echo "<tr>";
			echo "<td>" . "<center>" . $counter . "</center>" . "</td>";
			echo "<td>" . $row['kod'] . "</td>";
			echo "<td>" . $row['model'] . "</td>";
			echo "<td>" . $row['jenama'] . "</td>";
			echo "<td>" . $row['diterima'] . "</td>";
			//echo "<td id="jumlah">"  "</td>";
			echo "</tr>";
			$counter++;
			}
		echo "</table>";
		mysqli_close($conn);
	?>
<script>
    function calculateAmount() {
		bpsi = document.getElementById("bpsi").value;
		bpss = document.getElementById("bpss").value;
		bpin = document.getElementById("bpin").value;
		stok = document.getElementById("stok").value;
        var total = bpsi + bpss + bpin;
		var baki = stok - total.value;
        /*display the result*/
        var divobj = document.getElementById("jumlah");
        divobj.value = tot_price;
		var display = document.getElementById("lulus");
        display.value = terima;
		var keluar = document.getElementById("keluar");
		keluar.value = terima;
		var lebihan = document.getElementById("lebihan");
		lebihan.value = catatan;
		
    }
</script>
</body>
</html>