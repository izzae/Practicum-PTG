<!DOCTYPE html>
<?php
   include "conn.php";
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
	   
      
      $uname = mysqli_real_escape_string($conn,$_POST['username']);// username and password sent from form 
      $password = mysqli_real_escape_string($conn,$_POST['password']); 
	  
	  if ($uname != "" && $password != ""){

        $sql_query = "select count(*) as cntUser from pengguna where nokp_pengguna='".$uname."' and katalaluan='".$password."'";
        $result = mysqli_query($conn,$sql_query);
        $row = mysqli_fetch_array($result);

        $count = $row['cntUser'];

        if($count > 0){
            $_SESSION['uname'] = $uname;
            header('Location: utama.php');
        }else{
            echo "<script>alert('MAAF NAMA PENGGUNA ATAU KATA LALUAN ANDA SALAH!')</script>";
        }

    }
   }
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
}

* {
  box-sizing: border-box;
  width: 600px;
  margin: auto;
}

/* style the container */
.container {
  position: relative;
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px 0 30px 0;
} 

/* style inputs and link buttons */
input,
.btn {
  width: 98%;
  padding: 12px;
  border: none;
  border-radius: 4px;
  margin: 5px;
  opacity: 0.85;
  display: inline-block;
  font-size: 17px;
  line-height: 20px;
  text-decoration: none;

  /*width: 100%;
  padding: 12px;
  border: none;
  border-radius: 4px;
  margin: 3px 0;
  opacity: 0.85;
  display: inline-block;
  font-size: 17px;
  line-height: 20px;
  text-decoration: none;*/
}

input:hover,
.btn:hover {
  opacity: 1;
}

img {
  display: block;
  margin-left: auto;
  margin-right: auto;
}

/* style the submit button */
input[type=submit] {
  background-color: #04AA6D;
  color: white;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

/* show password eye icon*/
.container i {
    cursor: pointer;
	display: inline-block;
}

/* Two-column layout */
.col {
  float: left;
  width: 50%;
  margin: auto;
  padding: 0 50px;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* hide some text on medium and large screens */
.hide-md-lg {
  display: none;
}

/* bottom container */
.bottom-container {
  text-align: center;
  background-color: #666;
  border-radius: 0px 0px 4px 4px;
}

</style>
</head>
<body>
<br/>
<br/>
<br/>
<br/>
<div class="container">
  <form action="" method="post">
    <div class="row">
      <h2 style="text-align:center">LOG MASUK PENGGUNA</h2>
	  <div class="vl">
      </div>
	  
	  <!--div class="col">
		<img src="image/stok.png" style="width:100%">     
	 </div>

      <div class="col">
        <div class="hide-md-lg">
        </div-->
		
		<img src="image/stok.png" style="width:85%">
        <input type="text" name="username" placeholder="Kata Pengguna" >
		<input type="password" name="password" autocomplete="current-password" id="id_password"  maxlength="8" placeholder="Kata Laluan">
		<i class="far fa-eye" id="togglePassword"></i>
        <input type="submit" value="Log Masuk">
      </div>
      
    </div>
  </form>
</div>

<div class="bottom-container">
  <div class="row">
    <div class="col">
      <a href="daftarpengguna.php" style="color:white" class="btn">Daftar Masuk</a>
    </div>
    <div class="col">
      <a href="#" style="color:white" class="btn">Lupa Kata Laluan</a>
    </div>
  </div>
</div>
</body>
<script>
/*function myFunction() {
  var x = document.getElementById("myInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}*/
const togglePassword = document.querySelector('#togglePassword');
  const password = document.querySelector('#id_password');
 
  togglePassword.addEventListener('click', function (e) {
    // toggle the type attribute
    const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
    password.setAttribute('type', type);
    // toggle the eye slash icon
    this.classList.toggle('fa-eye-slash');
});
</script>
</html>
