<?php 

include "conn.php";

$departid = 0;

if(isset($_POST['kod'])){
   $departid = mysqli_real_escape_string($conn,$_POST['kod']); // department id
}

$users_arr = array();

if($departid > 0){
   $sql = "SELECT id,model FROM stok WHERE kod=".$departid;

   $result = mysqli_query($conn,$sql);

   while( $row = mysqli_fetch_array($result) ){
      $userid = $row['id'];
      $name = $row['model'];

      $users_arr[] = array("id" => $userid, "model" => $name);
   }
}
// encoding array to json format
echo json_encode($users_arr);