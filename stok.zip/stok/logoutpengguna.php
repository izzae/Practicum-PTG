<?php
session_start();

if(isset($_SESSION["uname"])){
	session_destroy();
}
?>

<center><p>SILA TUNGGU SEBENTAR ANDA AKAN DIBAWA KE HALAMAN LOG MASUK DALAM MASA <span id="seconds">5</span> SAAT LAGI.
</p></center>

<script>
// Countdown timer for redirecting to another URL after several seconds

var seconds = 5; // seconds for HTML
var foo; // variable for clearInterval() function

function redirect() {
    document.location.href = 'loginpengguna.php';
}

function updateSecs() {
    document.getElementById("seconds").innerHTML = seconds;
    seconds--;
    if (seconds == -1) {
        clearInterval(foo);
        redirect();
    }
}

function countdownTimer() {
    foo = setInterval(function () {
        updateSecs()
    }, 1000);
}

countdownTimer();
</script>



