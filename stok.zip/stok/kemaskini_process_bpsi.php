<html>
<head>
<style>
body{
display: none;}
</style>
</head>
<body>
<!--form method="post" action="senarai_bpsi.php"-->
<?php
	include_once 'database.php';
	if(isset($_POST['update']))
	{	 
		$id_bpsi = $_REQUEST['id'];

		$rujukan = $_POST['rujukan'];
		$no_kod = $_POST['no_kod'];
		$perihal_stok = $_POST['perihal_stok'];
		$kuantiti_mohon = $_POST['kuantiti_mohon'];
		$catatan_mohon = $_POST['catatan_mohon'];
		$baki = $_POST['baki'];
		$kuantiti_lulus = $_POST['kuantiti_lulus'];
		$catatan_pegawai = $_POST['catatan_pegawai'];
		$kuantiti_terima = $_POST['kuantiti_terima'];
		$catatan_terima = $_POST['catatan_terima'];
		$sql = "UPDATE bpsi SET rujukan='$rujukan', no_kod='$no_kod', perihal_stok='$perihal_stok', kuantiti_mohon='$kuantiti_mohon', catatan_mohon='$catatan_mohon',
		baki='$baki', kuantiti_lulus='$kuantiti_lulus', catatan_pegawai='$catatan_pegawai', kuantiti_terima='$kuantiti_terima', catatan_terima='$catatan_terima' WHERE id=$id_bpsi";
		echo $sql;
		if (mysqli_query($conn, $sql)) {
		echo "<script>alert('KEMASKINI PERMOHONAN STOK (INDIVIDU KEPADA STOR) TELAH BERJAYA!');
		window.location.href='senarai_bpsi.php';
		</script>";
		} else {
			echo "Error: " . $sql . "
		" . mysqli_error($conn);
			}
		mysqli_close($conn);
	}
?>
</form>
</body>
</html>