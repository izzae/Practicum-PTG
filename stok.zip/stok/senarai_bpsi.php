<?php include "conn.php";?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style>
table{
 width: 100%; /* For Responsive design set 100% */
 border-collapse: collapse;
 margin: 30px 0px 30px;
 font-size: 14px;
 margin-left: auto; 
 margin-right: auto;
 }
table tr {
 height: 40px;
 }
table th {
 background: #D7DBDD;
 color: black;
 border: 1px solid #ccc;
 font-weight: bold;
 text-transform:uppercase;
 font-size: 14px;
 text-align:center;
}
table td{
 padding: 6px 6px 6px 10px;
 border: 1px solid #ccc;
 text-align:center;
 font-size: 12px;
}
</style>
</head>
<body>
<?php include 'style\menu2.php';?>

<center><h3>Senarai Borang Permohonan Stok (Individu Kepada Stor) (BPSI)</h3></center>
	
	<?php  
		$a = "SELECT * FROM bpsi order by no_kod ASC";
		$result = mysqli_query($conn,$a) or die(mysqli_error());
		echo "<table border='1'>
		<tr>
			<th>&nbsp;Bil</th>
			<th>&nbsp;Nombor Kod</th>
			<th>&nbsp;Perihal Stok</th>
			<th>&nbsp;Kuantiti Dimohon</th>
			<th>&nbsp;Nama Pemohon</th>
			<th>&nbsp;Kemaskini</th>
			<th>&nbsp;Cetak</th>
		</tr>";
		
		$counter = 1;
		while($row = mysqli_fetch_assoc($result))
			{
				$id=$row['id'];
			echo "<tr>";
			echo "<td>" . $counter . "</td>";
			echo "<td>" . $row['no_kod'] . "</td>";
			echo "<td>" . $row['perihal_stok'] . "</td>";
			echo "<td>" . $row['kuantiti_mohon'] . "</td>";
			echo "<td>" . $row['pemohon'] . "</td>";
			echo "<td><a href = 'kemaskini_bpsi.php?id=$id'><img src='image/edit.png' width='30' height='30'></a>". "</td>";
			echo "<td><a href = 'cetak/cetak_bpsi.php?id=$id' target='_blank'><img src='image/print.png' width='30' height='30'></a>". "</td>";
			echo "</tr>";
			$counter++;
			}
		echo "</table>";
		mysqli_close($conn);
	?>
</body>
</html>