<?php
include 'conn.php';
$id_btb = $_REQUEST['id'];
?>
<!DOCTYPE html>
<!--form untuk daftar aset keseluruhan-->
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: white;
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  background-color: #f1f1f1;
}

/* Full-width input fields */
input[type=text], input[type=password], input[type=date], textarea, select {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: white;
  text-transform:uppercase;
}

input[type=text]:focus, input[type=password]:focus, input[type=date]:focus, textarea:focus, select:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid black;
  margin-bottom: 25px;
}

h4 {
	text-align: center;
}

/* Set a style for the submit button */
input[type=submit] {
  background-color: #A6ACAF;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

input[type=submit]:hover {
  opacity: 1;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>

<body>
<?php
include('style/menu2.php');

	$a = "SELECT * FROM stok where id = $id_btb order by kod ASC";
		$result = mysqli_query($conn,$a) or die(mysqli_error());
	$row = mysqli_fetch_assoc($result)
?>
<form method="post" action="kemaskini_process_btb.php?id=<?php echo $id_btb?>">
  <div class="container">
 
    <h3>KEMASKINI TERIMAAN BARANG-BARANG (BTB)</h3>
    <!--p>Please fill in this form to create an account.</p-->
    <hr>
	
	<label for="name"><b>No. Rujukan BTB</b></label>
    <input type="text" placeholder="Sila masukkan no. rujukan BTB" name="rujukan" value="<?php echo $row['rujukan'];?>">
	
	<label for="brand"><b>Jenis</b></label>
	<input type="text" value="<?php echo $row['jenis'];?>" name="jenis">
	
	<hr>
	
	<label for="name"><b>Nama Pembekal/Agen Penghantaran/Pemberi</b></label>
    <input type="text" name="nama_syarikat" value="<?php echo $row['nama_syarikat'];?>">
	
	<label for="address"><b>Alamat Pembekal/Agen Penghantaran/Pemberi</b></label>
    <input type="text" name="alamat" value="<?php echo $row['alamat'];?>">

    <label for="receive"><b>Jenis Penerimaan</b></label>
    <input type="text" name="jenis_penerimaan" value="<?php echo $row['jenis_penerimaan'];?>">
	
	<hr>
	
	<h4>Pesanan Kerajaan (PK)/Kontrak/Surat Kelulusan</h4>
	<label for="no"><b>Nombor/Rujukan</b></label>
    <input type="text" name="no_rujukan" value="<?php echo $row['no_rujukan'];?>">

    <label for="item"><b>Tarikh</b></label>
    <input type="date" name="tkh_pesanan" value="<?php echo $row['tkh_pesanan'];?>">
	
	<hr>
	
	<h4>Nota Hantaran (DO)</h4>
	<label for="code"><b>Nombor</b></label>
    <input type="text" name="no_hantaran" value="<?php echo $row['no_hantaran'];?>">

    <label for="item"><b>Tarikh</b></label>
    <input type="date" name="tkh_hantaran" value="<?php echo $row['tkh_hantaran'];?>">
	
	<hr>
	
	<label for="code"><b>Maklumat Penghantaran</b></label>
    <input type="text" name="maklumat_hantran" value="<?php echo $row['maklumat_hantran'];?>">
	
	<hr>


	<input type="submit" name="update" value="KEMASKINI">
  </div>
</form>

</body>
</html>
