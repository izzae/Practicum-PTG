<?php include "conn.php";?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Sistem Daftar Stok</title>
<style>
table{
 width: 100%; 
 border-collapse: collapse;
 font-size: 14px;
 background-color: #fff;
 table-layout: auto;
 }
table tr {
 height: 40px;
 }
table th {
 background: #D7DBDD;
 color: black;
 font-weight: bold;
 text-align:center;
 text-transform:uppercase;
 border: 1px solid #ccc;
 font-size: 14px;
}
table td {
 padding: 6px 6px 6px 10px;
 border: 1px solid #ccc;
 font-size: 12px;
}
</style>
</head>
<body>
<?php include 'style\menu2.php';?>

<center><h3>Senarai Borang Terimaan Barang-Barang (BTB) KEW.PS-1 </h3></center>
	
	<?php  
		$a = "SELECT * FROM stok order by kod ASC";
		$result = mysqli_query($conn,$a) or die(mysqli_error());
		echo "<table border='1'>
		<tr>
			<th>&nbsp;Bil</th>
			<th>&nbsp;Nama Pembekal</th>
			<th>&nbsp;No Rujukan</th>
			<th>&nbsp;Tarikh Nota Hantaran</th>
			<th>&nbsp;Tambah Pembelian </th>
			<th>&nbsp;Kemaskini</th>
			<th>&nbsp;Cetak</th>
		</tr>";
		
		$counter = 1;
		while($row = mysqli_fetch_assoc($result))
			{
				$id=$row['id'];
			echo "<tr>";
			echo "<td>" . "<center>" . $counter . "</center>" . "</td>";
			echo "<td>" . "<center>" . $row['nama_syarikat'] . "</center>" . "</td>";
			echo "<td>" . $row['no_rujukan'] . "</td>";
			echo "<td>" . $row['tkh_hantaran'] ."</td>";
			echo "<td><center><a href = 'kemaskini_btb_stok.php?id=$id'><img src='image/register.png' width='30' height='30'></a>". "</center></td>";
			echo "<td><center><a href = 'kemaskini_btb.php?id=$id'><img src='image/edit.png' width='30' height='30'></a>". "</center></td>";
			echo "<td><center><a href = 'cetak/cetak_btb.php?id=$id' target='_blank'><img src='image/print.png' width='30' height='30'></a>". "</center></td>";
			echo "</tr>";
			$counter++;
			}
		echo "</table>";
		mysqli_close($conn);
	?>
</body>
</html>