<html>
<head>
</head>
<body>
<!---<form method="post" action="senarai_bpss.php">--->
<?php
	include_once 'conn.php';
	
	
	if(isset($_POST['update']))
	{	 
		$id_bpss = $_REQUEST['id'];
		
		$rujukan = $_POST['rujukan'];
		$nama_1 = $_POST['nama_1'];
		$alamat_1 = $_POST['alamat_1'];
		$no_kod = $_POST['no_kod'];
		$perihal_stok = $_POST['perihal_stok'];
		$kuantiti_mohon = $_POST['kuantiti_mohon'];
		$catatan_pemesan = $_POST['catatan_pemesan'];
		$kuantiti_terima = $_POST['kuantiti_terima'];
		$nama_2 = $_POST['nama_2'];
		$alamat_2 = $_POST['alamat_2'];
		$unit_pengukuran = $_POST['unit_pengukuran'];
		$baki_ada = $_POST['baki_ada'];
		$kuantiti_lulus = $_POST['kuantiti_lulus'];
		$seunit = $_POST['seunit'];
		$jumlah = $_POST['jumlah'];
		$catatan_bekalan = $_POST['catatan_bekalan'];
		$kuantiti_keluar = $_POST['kuantiti_keluar'];
		$pembungkusan = $_POST['pembungkusan'];
		$sql = "UPDATE bpss SET rujukan='$rujukan', nama_1='$nama_1', alamat_1='$alamat_1', no_kod='$no_kod', perihal_stok='$perihal_stok', kuantiti_mohon='$kuantiti_mohon', 
		catatan_pemesan='$catatan_pemesan',kuantiti_terima='$kuantiti_terima', nama_2='$nama_2', alamat_2='$alamat_2', unit_pengukuran='$unit_pengukuran', 
		baki_ada='$baki_ada', kuantiti_lulus='$kuantiti_lulus', seunit='$seunit', jumlah='$jumlah', catatan_bekalan='$catatan_bekalan', kuantiti_keluar='$kuantiti_keluar', 
		pembungkusan='$pembungkusan' WHERE id=$id_bpss";
		echo $sql;
		
		if (mysqli_query($conn, $sql)) {
		echo "<script>alert('KEMASKINI PERMOHONAN STOK (ANTARA STOR) TERIMAAN BARANG-BARANG TELAH DITERIMA!');
		window.location.href='senarai_bpss.php';
		</script>";
		} else {
			echo "Error: " . $sql . "
		" . mysqli_error($conn);
			}
		mysqli_close($conn);
	}
?>
</form>
</body>
</html>