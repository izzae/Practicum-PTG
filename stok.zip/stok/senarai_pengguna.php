<?php include "conn.php";?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
<style>
table{
 width: 100%; /* For Responsive design set 100% */
 border-collapse: collapse;
 margin: 30px 0px 30px;
 background-color: #fff;
 font-size: 14px;
 margin-left: auto; 
 margin-right: auto;
 }
 
table tr {
 height: 40px;
 }
 
table th {
 background: #333;
 color: #fff;
 font-weight: bold;
 font-size: 18px;
}

table th{
 padding: 6px 6px 6px 10px;
 border: 1px solid #ccc;
 text-align:center;
}

table td{
 padding: 6px 6px 6px 10px;
 border: 1px solid #ccc;
 text-align:left;
}

/* CSS3 Zebra Striping */
table tr:nth-of-type(odd) {
 background: #eee;
}

input[type=text] {
  width: 40%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin:auto;
  max-width:300px
}
</style>
<body>
<?php include 'style\menu2.php';?>

<center><h1>Senarai Kod</h1></center>

		<?
		$a = "SELECT * FROM pengguna";
		/*if(isset($_GET['search'])){
			$name = mysqli_real_escape_string($conn, htmlspecialchars($_GET['search']));
			$a = "SELECT * FROM stok WHERE jenama ='$name' or jenis ='$name'" ;
		}*/
		$result = mysqli_query($conn,$a) or die(mysqli_error());
		echo "<table border='1'>
		<tr>
			<th>&nbsp;BIL</th>
			<th>&nbsp;PENGGUNA</th>
			<th>&nbsp;NO. KAD PENGENALAN</th>
			<th>&nbsp;JABATAN</th>
			<!--th colspan = '2'>Action</th-->
		</tr>";
		
		$counter = 1;
		while($row = mysqli_fetch_assoc($result))
			{
			echo "<tr>";
			echo "<td>" . "<center>" . $counter . "</center>" . "</td>";
			echo "<td>" . $row['nama_pengguna']. "</td>";
			echo "<td>" . $row['nokp_pengguna'] . "</td>";
			echo "<td>" . $row['jabatan']. "</td>";
			/*<td>
			<?php echo $row->id;?>" onclick="return confirm('Are You Sure')">Delete    
        </a> | <a href="index.php?id =     
            <?php echo $row->id;?>" onclick="return confirm('Are You Sure')">Edit    
        </a> </td>*/
		
			echo "</tr>";
			$counter++;
			}
		echo "</table>";
		mysqli_close($conn);
		?>
</body>
</html>