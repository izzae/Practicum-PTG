<?
//session_start();
//session_destroy();--ini untuk kill session user......
?><head>
<meta http-equiv="refresh" content="5; URL=login.php">---ini untuk redirect ke page login...setelah session kill
</head>

<?
//header("refresh: 5; thankyou.htm";---ini notification seteleh refresh page
?>

<center>
<br>

<h1>Anda telah keluar dari sistem</h1>
<font>Terima Kasih</font><br>
<a href='login.php'>Sila Klik untuk Login </a><br>atau tunggu sebentar anda akan kembali ke Login Page---ini untuk user yang tiadak mahu tunggu sistem refresh 5saat boleh klik direct
</center>
<br>
