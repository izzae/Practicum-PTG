<?php
include 'conn.php';
$id_kod = $_REQUEST['id'];
?>
<!DOCTYPE html>
<!--form untuk daftar aset keseluruhan-->
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: white;
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  background-color: #f1f1f1;
}

/* Full-width input fields */
input[type=text], input[type=password], input[type=date], textarea, select {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: white;
  text-transform:uppercase;
}

input[type=text]:focus, input[type=password]:focus, input[type=date]:focus, textarea:focus, select:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid black;
  margin-bottom: 25px;
}

h4 {
	text-align: center;
}

/* Set a style for the submit button */
input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

input[type=submit]:hover {
  opacity: 1;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>

<body>
<?php
include('style/menu2.php');

	$a = "SELECT * FROM stok where id = $id_kod";
		$result = mysqli_query($conn,$a) or die(mysqli_error());
	$row = mysqli_fetch_assoc($result);
	//echo 
?>
	
<form method="post" action="process_bpss.php?id=<?php echo $id_kod?>">
  <div class="container">
 
    <h1>Kemaskini Permohonan Stok (Antara Stor) (BPSS)</h1>
    <!--p>Please fill in this form to create an account.</p-->
    <hr>
	
	<label for="name"><b>Nama Stor Pemesan</b></label>
    <input type="text" placeholder="Sila masukkan nama stor pemesan" name="nama_1">
	
	<label for="address"><b>Alamat Stor Pemesan</b></label>
    <input type="text" placeholder="Sila masukkan alamat stor pemesan" name="alamat_1">
	
	<hr>
	
	<h4>Dilengkapkan oleh stor pemesan</h4>
	
	<label for="no"><b>No. Kod</b></label>
    <input type="text" placeholder="Sila masukkan no. kod" name="no_kod" value="<?php echo $row['kod'];?>" disabled>

    <label for="item"><b>Perihal Stok</b></label>
    <input type="text" placeholder="Sila masukkan perihal stok" name="perihal_stok" value="<?php echo $row['model'];?>" disabled>
	
	<label for="name"><b>Kuantiti dimohon</b></label>
    <input type="text" placeholder="Sila masukkan nama pembekal/agen penghantaran/pemberi" name="kuantiti_mohon">
	
	<label for="note"><b>Catatan</b></label>
	<textarea name="catatan_pemesan" placeholder="Sila tulis catatan" style="height:200px"></textarea>

    <label for="receive"><b>Kuantiti Diterima</b></label>
    <input type="text" placeholder="Sila masukkan perihal jenis penerimaan" name="kuantiti_terima" onchange="calculateAmount()" id="terima">
	
	<hr>
	
	<label for="name"><b>Nama Stor Pemesan</b></label>
    <input type="text" placeholder="Sila masukkan nama pembekal/agen penghantaran/pemberi" name="nama_2">
	
	<label for="address"><b>Alamat Stor Pemesan</b></label>
    <input type="text" placeholder="Sila masukkan alamat pembekal/agen penghantaran/pemberi" name="alamat_2">
	
	<hr>
	
	<h4>Dilengkapkan oleh stor pengeluar</h4>
	<h4>BAHAGIAN BEKALAN KAWALAN DAN AKAUN</h4>
	<label for="no"><b>Unit pengukuran</b></label>
    <input type="text" placeholder="Sila masukkan no. kod" name="unit_pengukuran" value="unit">
	
	<label for="no"><b>Baki Sedia Ada</b></label>
    <input type="text" placeholder="Sila masukkan no. kod" name="baki_ada" value="<?php echo $row['diterima'];?>" onchange="calculateAmount()" id="baki">
	
	<label for="no"><b>Kuantiti Diluluskan</b></label>
    <input type="text" placeholder="Sila masukkan no. kod" name="kuantiti_lulus" onchange="calculateAmount()" id="lulus">
	
	<h4>Harga (RM)</h4>
	
	<label for="no"><b>Seunit</b></label>
    <input type="text" placeholder="Sila masukkan no. kod" name="seunit" onchange="calculateAmount()" id="harga">
	
	<label for="no"><b>Jumlah</b></label>
    <input type="text" placeholder="Sila masukkan no. kod" name="jumlah" id="jumlah">

    <label for="note"><b>Catatan</b></label>
	<textarea name="catatan_bekalan" placeholder="Sila tulis catatan" style="height:200px" id="lebihan"></textarea>
	
	<hr>
	
	<h4>BAHAGIAN SIMPANAN</h4>
	<label for="code"><b>Kuantiti Dikeluarkan</b></label>
    <input type="text" placeholder="Sila masukkan no. kod" name="kuantiti_keluar" name="kuantiti_keluar" id="keluar">
	
	<label for="code"><b>Pembungkusan (Perlu/Tidak Perlu)</b></label>
    <input type="text" placeholder="Sila masukkan no. kod" name="pembungkusan">
	
	<label for="code"><b>No. Borang Pembungkusan Stok (BPS)</b></label>
    <input type="text" placeholder="Sila masukkan no. kod" name="" >

	<input type="submit" name="save" value="DAFTAR">
  </div>
</form>
<script>
    function calculateAmount() {
		terima = document.getElementById("terima").value;
		harga = document.getElementById("harga").value;
		lulus = document.getElementById("lulus").value;
		baki = document.getElementById("baki").value;
		keluar = document.getElementById("keluar").value;
        var tot_price = terima * harga;
		var catatan = baki - terima;
        /*display the result*/
        var divobj = document.getElementById("jumlah");
        divobj.value = tot_price;
		var display = document.getElementById("lulus");
        display.value = terima;
		var keluar = document.getElementById("keluar");
		keluar.value = terima;
		var lebihan = document.getElementById("lebihan");
		lebihan.value = catatan;
    }
</script>
</body>
</html>
