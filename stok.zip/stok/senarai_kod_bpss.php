<?php include "conn.php";?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
<style>
table{
 width: 100%; /* For Responsive design set 100% */
 border-collapse: collapse;
 margin: 30px 0px 30px;
 background-color: #fff;
 margin-left: auto; 
 margin-right: auto;
 }
 
table tr {
 height: 40px;
 }
 
table th {
 background: #D7DBDD;
 color: black;
 font-weight: bold;
 font-size: 14px;
 padding: 6px 6px 6px 10px;
 border: 1px solid #ccc;
 text-align:center;
}

table td, th{
 padding: 6px 6px 6px 10px;
 border: 1px solid #ccc;
 text-align:left;
 font-size: 12px;
}

input[type=text] {
  width: 40%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin:auto;
  max-width:300px
}
</style>
<body>
<?php include 'style\menu2.php';?>

<center><h1>Sila pilih kod sebelum ke borang BPSS</h1></center>

		<?
		$a = "SELECT * FROM stok order by kod asc";
		/*if(isset($_GET['search'])){
			$name = mysqli_real_escape_string($conn, htmlspecialchars($_GET['search']));
			$a = "SELECT * FROM stok WHERE jenama ='$name' or jenis ='$name'" ;
		}*/
		$result = mysqli_query($conn,$a) or die(mysqli_error());
		echo "<table border='1'>
		<tr>
			<th>&nbsp;BIL</th>
			<th>&nbsp;NO.KOD</th>
			<th>&nbsp;JENIS</th>
			<th>&nbsp;MODEL</th>
			<!--th colspan = '2'>Action</th-->
		</tr>";
		
		$counter = 1;
		while($row = mysqli_fetch_assoc($result))
			{
				$id=$row['id'];
			echo "<tr>";
			echo "<td>" . "<center>" . $counter . "</center>" . "</td>";
			echo "<td><a href = 'daftar_bpss.php?id=$id'>" . $row['kod'] . "</a>". "</td>";
			echo "<td>" . $row['jenis']. "</td>";
			echo "<td>" . $row['model'] . "</td>";
			/*<td>
			<?php echo $row->id;?>" onclick="return confirm('Are You Sure')">Delete    
        </a> | <a href="index.php?id =     
            <?php echo $row->id;?>" onclick="return confirm('Are You Sure')">Edit    
        </a> </td>*/
		
			echo "</tr>";
			$counter++;
			}
		echo "</table>";
		mysqli_close($conn);
		?>
</body>
</html>