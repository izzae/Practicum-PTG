<?php 
include ('../conn.php');
$id_kod = $_REQUEST['id'];
$kod =$_REQUEST['id2'];
?>
<!doctype html>
<html>
<head>
	<style>
	#list, #list td{
  border: 1px solid black;
  border-collapse: collapse;
  text-align: left;
	}
  #list th {
  border: 1px solid black;
  border-collapse: collapse;
  text-align: center;
  background-color: #D7DBDD;
		}
	  a {
  text-decoration: none;
  display: inline-block;
  padding: 8px 16px;
}

a:hover {
  background-color: #ddd;
  color: black;
}

.previous {
  background-color: #f1f1f1;
  color: black;
}

.next {
  background-color: #04AA6D;
  color: white;
}
</style>
<meta charset="utf-8">
<title>Sistem Daftar Stok</title>
</head>

<body>
		<a href="cetak/cetak_transaksi_stok.php" class="previous" target='_blank'>Kembali Ke Senarai Stok &raquo;</a>
	<br/>
	
	<?php
	$a = "select a.kod, a.seunit, a.jumlah, a.diterima, 
	b.kuantiti_lulus, 
	c.kuantiti_lulus, 
	d.kuantiti_lulus 
	from stok a 
	left outer join bpin b on a.kod=b.no_kod 
	left outer join bpsi c on b.no_kod=c.no_kod 
	left outer join bpss d on c.no_kod=d.no_kod 
	where a.kod=$kod";
	
	$result = mysqli_query($conn,$a) or die(mysqli_error());
	$result = $conn->query($a);
	?>
	
	
<table width=100% border="0">
  <tbody>
    <tr>
      <td scope="col" align="left">Pekeliling Perbendaharaan Malaysia</td>
      <td scope="col" align="right">AM 6.3 Lampiran A</td>
    </tr>
  </tbody>
</table>
	<br/>
<table width=100% border="0">
  <tbody>
    <tr>
      <th scope="col" align="center">BAHAGIAN B</th>
    </tr>
  </tbody>
</table>
	<br/>
<table width=100% border="0">
  <tbody>
    <tr>
      <th scope="col" align="left"><p>Transaksi Stok </p></th>
    </tr>
  </tbody>
</table>
	<br/>
<table id="list" width=100% border="1">
	  <tbody>
	    <tr>
	      <th rowspan="2" scope="col">Tarikh</th>
	      <th rowspan="2" scope="col">No. PK/BTB/BPSS/BPSI/BPIN</th>
	      <th rowspan="2" scope="col">Terima Daripada/Keluar Daripada</th>
	      <th colspan="3" scope="col">Terimaan</th>
	      <th colspan="2" scope="col">Keluaran</th>
	      <th colspan="2" scope="col">Baki</th>
	      <th rowspan="2" scope="col">Nama Pegawai</th>
        </tr>
	    <tr>
	      <th>Kuantiti</th>
	      <th>Seunit (RM)</th>
	      <th>Jumlah (RM)</th>
	      <th>Kuantiti</th>
	      <th>Jumlah (RM)</th>
	      <th>Kuantiti</th>
	      <th>Jumlah (RM)</th>
        </tr>
	    <tr>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td colspan="5">Baki dibawa ke hadapan ....................................................</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
        </tr>
		  <?
			  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		  
			?>
		  <tr>
	      <td><?php echo $rowb["tkh_transaksi"];?>&nbsp;</td>
	      <td><?php echo $rowb["no_nota"];?>&nbsp;</td>
	      <td><?php echo $rowb["terima"];?>&nbsp;</td>
	      <td><?php echo $row["diterima"];?>&nbsp;</td>
	      <td><?php echo $row["seunit"];?>&nbsp;</td>
	      <td><?php echo $row["jumlah"];?>&nbsp;</td>
		
	      <td><?php echo $row["kuantiti_lulus"];?>&nbsp;</td>
	      <td><?php echo $rowb["jumlah_stok"];?>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
	      <td>&nbsp;</td>
      </tbody>
	<?php
			//$counter++;
			}
		  ?>
</table>
	<?php
			  }
			$conn->close();?>
	<table width="324">
	  <tbody>
	    <tr>
	      <td width="318" align="left" scope="col">Nota:</td>
        </tr>
	    <tr>
	      <td>PK=Pesanan Kerajaan</td>
        </tr>
	    <tr>
	      <td>BTB=Borang Terimaan Barang-Barang</td>
        </tr>
	    <tr>
	      <td>BPSS=Borang Permohonan Stok (KEW.PS-7)</td>
        </tr>
	    <tr>
	      <td>BPSI=Borang Permohonan Stok (KEW.PS-8)</td>
        </tr>
	    <tr>
	      <td>BPIN=Borang Pindahan Stok (KEW.PS-17)</td>
        </tr>
      </tbody>
</table>
</body>
</html>