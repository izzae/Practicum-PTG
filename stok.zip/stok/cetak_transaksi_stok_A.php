<?php 
include ('conn.php');
$id_kod = $_REQUEST['id'];
$kod =$_REQUEST['id2'];
?>
<!doctype html>
<html>
<head>
	<style>
	#list, #list td{
  border: 1px solid black;
  border-collapse: collapse;
  text-align: center;
	}
  #list th {
  border: 1px solid black;
  border-collapse: collapse;
  text-align: center;
  background-color: #D7DBDD;
}
		 a {
  text-decoration: none;
  display: inline-block;
  padding: 8px 16px;
}

a:hover {
  background-color: #ddd;
  color: black;
}

.previous {
  background-color: #f1f1f1;
  color: black;
}

.next {
  background-color: #04AA6D;
  color: white;
}
</style>
<title>Sistem Daftar Stok</title>
</head>
<body>
	<a href="senarai_kod.php" class="previous">&laquo; Kembali ke Senarai Kod</a>
	<a href="cetak/cetak_transaksi_stok.php?id=<?php echo $_REQUEST['id']; ?>&id2=<?php echo $_REQUEST['id2'];?>" class="next">Kembali ke Cetak Bahagian B &raquo;</a>
	<br/>
		<?php
	$a = "SELECT * FROM stok where id = $id_kod order by kod ASC";
	$result = mysqli_query($conn,$a) or die(mysqli_error());
	$row = mysqli_fetch_assoc($result);
	?>
<table width='100%' border="0">
  <tbody>
    <tr>
      <td scope="col" align="left">Pekeliling Perbendaharaan Malaysia</td>
      <td scope="col" align="right">AM 6.3 Lampiran A</td>
    </tr>
  </tbody>

</table>
	<table  width=100% border="0">
  <tbody>
    <tr>
      <th scope="col" align="right">KEW.PS-3</th>
    </tr>
  </tbody>
</table>
	<br/>
<table  width=100% border="0">
  <tbody>
    <tr>
      <th scope="col" align="right">No. Kad:.........................</th>
    </tr>
  </tbody>
</table>
<table  width=100% border="0">
  <tbody>
    <tr>
      <th scope="col" align=""><p>DAFTAR STOK</p></th>
    </tr>
  </tbody>
</table>
	<br/>
<table  width=100% border="0">
  <tbody>
    <tr>
      <th scope="col" align="left">Nama Stor    :</th>
    </tr>
  </tbody>
</table>
<table  width=100% border="0">
  <tbody>
    <tr>
	  <th scope="col" align="left">Perihal Stok :</th>
    </tr>
  </tbody>
</table>
	<br/>
<table width=100% border="0">
  <tbody>
    <tr>
	  <th scope="col" align="center">BAHAGIAN A</th>
    </tr>
  </tbody>
</table>
<table id="list" width="100%">

  <tbody>
    <tr>
      <th width="159" height="46" rowspan="2" scope="col">No. Kod</th>
      <td colspan="4" rowspan="2" scope="col"><?php echo $row['kod'];?></td>
      <th width="211" rowspan="2" scope="col">Kumpulan</th>
      <td width="436" scope="col">&nbsp;</td>
    </tr>
    <tr>
      <td scope="col">&nbsp;</td>
    </tr>
    <tr>
      <th height="50">Unit Pengukuran</th>
      <td colspan="4"> <?php echo $row['unit_pengukuran'];?>&nbsp;</td>
      <th>Pergerakan</th>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <th rowspan="2">Lokasi Penyimpanan Stok</th>
      <th width="146" height="46">Gudang/Seksyen</th>
      <th width="115">Baris</th>
      <th width="124">Rak</th>
      <th width="109">Tingkat</th>
      <th>Petak</th>
      <th>Kod Lokasi Penuh</th>
    </tr>
    <tr>
      <td height="41">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </tbody>
</table>
	<br/>
<table id="list" width="100%">
  <tbody>
    <tr>
      <th height="33" colspan="4" scope="col">PARAS STOK</th>
    </tr>
    <tr>
      <td><strong><strong>TAHUN</strong></td>
      <td><strong><strong>MAKSIMUM </strong>        <p><strong>(Kuantiti)</strong></p></td>
      <td><strong><strong>MENOKOK</strong>        <p><strong>(Kuantiti)</strong></p></td>
      <td><strong><strong>MINIMUM</strong>        <p><strong>(Kuantiti)</strong></p></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </tbody>
</table>
	<br/>
<table id="list" width="100%">
  <tbody>
    <tr>
      <th height="33" colspan="9" scope="col">TERIMAAN STOK SUKU TAHUN</th>
    </tr>
    <tr>
      <td rowspan="2"><strong>TAHUN</strong></td>
      <td colspan="2"><strong>PERTAMA</strong></td>
      <td colspan="2"><strong>KEDUA</strong></td>
      <td colspan="2"><strong>KETIGA</strong></td>
      <td colspan="2"><strong>KEEMPAT</strong></td>
    </tr>
    <tr>
      <td>Kuantiti</td>
      <td>Nilai (RM)</td>
      <td>Kuantiti</td>
      <td>Nilai (RM)</td>
      <td>Kuantiti</td>
      <td>Nilai (RM)</td>
      <td>Kuantiti</td>
      <td>Nilai (RM)</td>
    </tr>
    <tr>
      <td><?php echo date("Y", strtotime($row['ts']));?>&nbsp;</td>
      <td><?php echo $row['diterima'];?>&nbsp;</td>
      <td><?php echo $row['jumlah'];?>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <th height="33" colspan="9">KELUARAN STOK SUKU TAHUN</th>
    </tr>
    <tr>
      <td rowspan="2"><strong>TAHUN</strong></td>
      <td colspan="2"><strong>PERTAMA</strong></td>
      <td colspan="2"><strong>KEDUA</strong></td>
      <td colspan="2"><strong>KETIGA</strong></td>
      <td colspan="2"><strong>KEEMPAT</strong></td>
    </tr>
    <tr>
      <td>Kuantiti</td>
      <td>Nilai (RM)</td>
      <td>Kuantiti</td>
      <td>Nilai (RM)</td>
      <td>Kuantiti</td>
      <td>Nilai (RM)</td>
      <td>Kuantiti</td>
      <td>Nilai (RM)</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <th height="42" colspan="5">TERIMAAN STOK TAHUNAN</th>
      <th colspan="4">KELUARAN STOK TAHUNAN</th>
    </tr>
    <tr>
      <td><strong>TAHUN</strong></td>
      <td colspan="2">Kuantiti</td>
      <td colspan="2">Nilai (RM)</td>
      <td colspan="2">Kuantiti</td>
      <td colspan="2">Nilai (RM)</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td colspan="2">&nbsp;</td>
      <td colspan="2">&nbsp;</td>
      <td colspan="2">&nbsp;</td>
      <td colspan="2">&nbsp;</td>
    </tr>
	  <tr>
      <td>&nbsp;</td>
      <td colspan="2">&nbsp;</td>
      <td colspan="2">&nbsp;</td>
      <td colspan="2">&nbsp;</td>
      <td colspan="2">&nbsp;</td>
    </tr>
  </tbody>
</table>
<p>&nbsp;</p>
</body>
</html>