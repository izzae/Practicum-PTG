<?php
include_once 'database.php';

// Storing session data
/*session_start();// Starting session

if(!isset($_SESSION["uname"])){
	header('location:loginpengguna.php');
	exit;
}*/
?>

<body>
<?php include 'style\menu2.php';?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<form  method="post" action="cetak_transaksi_stok_A.php">
  <label for="brand"><b>No. Kod</b></label>
	<select name="kod">
		<?php
		$sql = "SELECT kod FROM stok";
		$result = mysqli_query($conn,$sql) or die(mysqli_error());
		while($row=mysqli_fetch_array($result)) {
		 echo "<option value='".$row['kod']."'>".$row['kod']."</option>";
		 if(isset($_POST['submit'])){
			$selected_val = $_POST['kod'];
		}
		}		
		?>
	</select>
	<input type="submit" name="save" value="SUBMIT">
</form>
</body>
</html>