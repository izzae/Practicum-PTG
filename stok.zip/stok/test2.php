<?

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "aset";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$a = "SELECT * FROM stok order by kod ASC";
		$result = mysqli_query($conn,$a) or die(mysqli_error());
		$row = mysqli_fetch_assoc($result);
		$ts=$row['ts'];
		echo	$row["alamat"];
		echo "<br/>";
		$b = "SELECT * FROM bpin ";
		$resultb = mysqli_query($conn,$b) or die(mysqli_error());
		$rowb = mysqli_fetch_assoc($resultb);
		$ts=$row['ts'];
		echo	$rowb["perihal_stok"];
?>