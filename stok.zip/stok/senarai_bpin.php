<?php include "conn.php";?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style>
table{
 width: 100%; /* For Responsive design set 100% */
 border-collapse: collapse;
 margin: 30px 0px 30px;
 margin-left: auto; 
 margin-right: auto;
 }
table tr {
 height: 40px;
 }
table th {
 background: #D7DBDD;
 color: black;
 font-weight: bold;
 padding: 6px 6px 6px 10px;
 border: 1px solid #ccc;
 text-align:center;
 text-transform:uppercase;
 font-size: 14px;
}

table td {
 padding: 6px 6px 6px 10px;
 border: 1px solid #ccc;
 text-align:left;
 font-size: 12px;
}
</style>
</head>
<body>
<?php include 'style\menu2.php';?>

<center><h3>Senarai Pindahan Stok (BPIN)</h3></center>
	
	<?php  
		/*a = "select stok.kod, bpin.perihal_stok, bpin.unit_pengukuran, bpin.jumlah_stok, bpin.kuantiti_lulus, stok.diterima 
		from stok 
		inner join bpin on bpin.no_kod=stok.kod 
		order by kod ASC";*/
		$a = "SELECT * FROM bpin WHERE CURDATE() order by no_kod ASC";
		$result = mysqli_query($conn,$a) or die(mysqli_error());
		echo "<table border='1'>
		<tr>
			<th>&nbsp;Bil</th>
			<th>&nbsp;No Kod</th>
			<th>&nbsp;Perihal Stok</th>
			<th>&nbsp;Unit Pengukuran</th>
			<th>&nbsp;Jumlah Nilai Stok (RM)</th>
			<th>&nbsp;Kuantiti Dilulus</th>
			<th>&nbsp;Nama Pemohon</th>
			<th>&nbsp;Kemaskini</th>
			<th>&nbsp;Cetak</th>
		</tr>";
		
		$counter = 1;
		while($row = mysqli_fetch_assoc($result))
			{
				$id=$row['id'];
			echo "<tr>";
			echo "<td><center>" . $counter . "</center></td>";
			echo "<td><center>" . $row['no_kod'] . "<center></td>";
			echo "<td>" . $row['perihal_stok'] . "</td>";
			echo "<td><center>" . $row['unit_pengukuran'] . "</center></td>";
			echo "<td><center>" . $row['jumlah_stok'] . "</center></td>";
			echo "<td><center>" . $row['kuantiti_lulus'] . "</center></td>";
			echo "<td>" . $row['nama_pemohon'] . "</td>";
			echo "<td><center><a href = 'kemaskini_bpin.php?id=$id'><img src='image/edit.png' width='30' height='30'></a></center></td>";
			echo "<td><center><a href = 'cetak/cetak_bpin.php?id=$id' target='_blank'><img src='image/print.png' width='30' height='30'></a></center></td>";
			echo "</tr>";
			$counter++;
			}
		echo "</table>";
		mysqli_close($conn);
	?>
</body>
</html>
