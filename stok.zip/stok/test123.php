<?php include "conn.php";?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `stok` WHERE CONCAT(`kod`,`model`, `jenis`) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `stok`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "aset");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}
?>
<style>
.styled-table {
    border-collapse: collapse;
	margin: 200px auto;
    font-size: 15px;
    font-family: sans-serif;
    width: 200px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
}
.styled-table thead tr {
    background-color: #F9AD4D;
    color: #ffffff;
    text-align: left;
}
.styled-table th,
.styled-table td {
    padding: 12px 15px;
}
.styled-table tbody tr {
    border-bottom: 1px solid #dddddd;
}

.styled-table tbody tr:nth-of-type(even) {
    background-color: #f3f3f3;
}

.styled-table tbody tr:last-of-type {
    border-bottom: 2px solid #F9AD4D;
}
.wrapper1{
  position: absolute;
  margin-top: -200px;
  top: 50%;
  left: 50%;
  transform: translate(-50%,-50%);
}
input[type=text] {
  width: 40%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid black;
  max-width:300px
}

.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 12px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 10px auto;
  cursor: pointer;
}
.container{
  position: relative;
  padding: 20px 50px;
}

.input{
  width: 400px;
  border: 3px solid #fff;
  background: #fff;
  padding: 15px 30px;
  border-radius: 50px;
  outline: none;
  font-size: 18px;
  color: #000000;
}

.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 12px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

</style>
<body>
<?php include 'style\menu2.php';?>

<center><h2>Senarai Stok</h2></center>

<form action="test123.php" method="post">
<div class="wrapper1">
<input type="text" name="valueToSearch" placeholder="Carian" />
<input type="submit" name="search" value="Carian" class="button">
<button class="button" onclick="window.print()" align="right">Cetak Senarai Stok</button>	
</div>		
	<table class="styled-table">
    <thead>
        <tr>
			<th>BIL</th>
			<th>JENAMA</th>
            <th>JENIS</th>
			<th>MODEL</th>
			<th>NO.KOD</th>
			<th>KUANTITI</th>
			<th>TARIKH DAFTAR</th>
			<th>UPDATE</th>
			<th>DELETE</th>
        </tr>
    </thead>
    <tbody>
        <tr>
	<?php 
	$count = 1;
	while($row = mysqli_fetch_array($search_result)):?>
                <tr>
					<td><?php echo $count++;?></td>
					<td><?php echo $row['jenama'];?></td>
                    <td><?php echo $row['jenis'];?></td>
                    <td><?php echo $row['model'];?></td>
                    <td><?php echo $row['kod'];?></td>
                    <td><?php echo $row['kuantiti'];?></td>
					<td><?php echo $row['ts'];?></td>
					<td><button class="button button1"><a href="return.php?id=<?php echo $row['id']?>">UPDATE</a></button></td>
					<td><button class="button button1"><a href="deleteData.php?id=<?php echo $row['id']?>"
					    onClick="return confirm('ADAKAH ANDA PASTI UNTUK MENGHAPUS DATA INI?!')">DELETE</a></button></td>
					</tr>
								</tr>
                <?php endwhile;?>
            </table>
        </form>
    </tbody>	
</table>
</body>
</html>	